#include "common.h"

/**
 * @breif printf重定向
 *
 */
/*
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif
*/



/**
 * @breif FIFO初始化
 *
 */
void FIFOQueue_Init(FIFO_Queue *fifo, Elem_Type* fifobuf, uint16_t bufsize)
{
  memset(fifo, 0, sizeof(FIFO_Queue));
  fifo->buf = fifobuf;
  fifo->flags = 0;
  fifo->free = bufsize;
  fifo->size = bufsize;
  fifo->write = 0;
  fifo->read  = 0;
}

/**
 * @breif FIFO清空
 *
 */
void FIFOQueue_Clear(FIFO_Queue *fifo)
{
  fifo->flags = 0;
  fifo->free = fifo->size;
  fifo->write = 0;
  fifo->read  = 0;
}

int8_t FIFOQueue_Put(FIFO_Queue *fifo, Elem_Type *data, uint32_t size)
{
  uint32_t Counter = 0;

  for(Counter = 0; Counter < size; Counter++)
  {
    if(fifo->free == 0)
    {
      fifo->flags |= FLAGS_OVERRUN;
      return -1;
    }

    fifo->buf[fifo->write] = data[Counter];
    fifo->write++;

    if(fifo->write == fifo->size)
    {
      fifo->write = 0;
    }

    fifo->free--;
  }

  return 0;
}


int8_t FIFOQueue_Get(FIFO_Queue *fifo, Elem_Type *data, uint32_t size)
{
  uint32_t Counter = 0;

  for(Counter = 0; Counter < size; Counter++)
  {
    if(fifo->free == fifo->size)
    {
      return -1;
    }

    data[Counter] = (fifo->buf)[fifo->read];
    fifo->read++;

    if(fifo->read == fifo->size)
    {
      fifo->read = 0;
    }

    fifo->free++;
  }

  return 0;
}

/* 缓冲区使用量 */
uint16_t FIFOQueue_Status(FIFO_Queue *fifo)
{
  return ((fifo->size) - (fifo->free));
}

/* 缓冲区剩余量 */
uint16_t FIFOQueue_Free(FIFO_Queue *fifo)
{
  return fifo->free;
}

/** @简介 - 字符串转整数
  * @参数 - 源字符串地址
  * @返回 - 无
  */
uint32_t str2int(const char *str)
{
  int temp = 0;
  const char *ptr = str;

  if (*str == '-' || *str == '+')
  {
    str++;
  }

  while(*str != 0)
  {
    if ((*str < '0') || (*str > '9'))
    {
      break;
    }

    temp = temp * 10 + (*str - '0');
    str++;
  }

  if (*ptr == '-')
  {
    temp = -temp;
  }

  return temp;
}



/** @简介 - 16进制字符串转64位整数
  * @参数 - 源字符串地址
  * @返回 - 无
  */
uint8_t hexstrToint64(uint8_t *str, uint64_t *ret)
{
  uint8_t *p1 = str;
  *ret = 0;

  if(p1[0] == '0' && (p1[1] == 'x' || p1[1] == 'X'))
  {
    p1 += 2;

    while(*p1 != '\0')
    {
      *ret = *ret * 16;

      if(*p1 >= '0' && *p1 <= '9')
      {
        *ret += (*p1 - '0');
      }
      else if(*p1 >= 'a' && *p1 <= 'f')
      {
        *ret += ((*p1 - 'a') + 0x0a);
      }
      else if(*p1 >= 'A' && *p1 <= 'F')
      {
        *ret += ((*p1 - 'A') + 0x0a);
      }
      else
      {
        return false;
      }

      p1++;
    }
  }
  else
  {
    return false;
  }

  return true;
}

/** @简介 - 64位整数转16进制字符串
  * @参数 - 源字符串地址
  * @返回 - 无
  */
void int64Tohexstr(uint64_t num , uint8_t *hexstr)
{
  uint64_t numtemp = num;
  uint8_t Lenth = 0;
  *hexstr++ = '0';
  *hexstr++ = 'x';
  Lenth = sprintf((char *)hexstr, "%x", (int)numtemp);
  hexstr += Lenth;
  sprintf((char *)&hexstr, "%x", (int)(numtemp >> 32));
}


/** @简介 - 16进制字符串转8位整数
  * @参数 - 源字符串地址
  * @返回 - 无
  */
uint8_t hexstrToint8(uint8_t *str, uint8_t *ret)
{
  uint8_t *p1 = str;
  *ret = 0;

  if(p1[0] == '0' && (p1[1] == 'x' || p1[1] == 'X'))
  {
    p1 += 2;

    while(*p1 != '\0')
    {
      *ret = *ret * 16;

      if(*p1 >= '0' && *p1 <= '9')
      {
        *ret += (*p1 - '0');
      }
      else if(*p1 >= 'a' && *p1 <= 'f')
      {
        *ret += ((*p1 - 'a') + 0x0a);
      }
      else if(*p1 >= 'A' && *p1 <= 'F')
      {
        *ret += ((*p1 - 'A') + 0x0a);
      }
      else
      {
        return false;
      }

      p1++;
    }
  }
  else
  {
    return false;
  }

  return true;
}

/** @简介 - 8位整数转16进制字符串
  * @参数 - 源字符串地址
  * @返回 - 无
  */
void int8Tohexstr(uint8_t num , uint8_t *hexstr)
{
  uint8_t numtemp = num;
  *hexstr++ = '0';
  *hexstr++ = 'x';
  sprintf((char *)hexstr, "%x", numtemp);
}
/*
  * @简介  - HEX转数字
  * @参数 - 0~9 A~F
  * @返回  - 0~16
  */
uint8_t HexToInt(uint8_t Hex)
{
  if((Hex >= '0') && (Hex <= '9'))
  {
    return Hex - '0';
  }
  else if((Hex >= 'A') && (Hex <= 'F'))
  {
    return Hex - 'A' + 10;
  }
  else if((Hex >= 'a') && (Hex <= 'f'))
  {
    return Hex - 'a' + 10;
  }
  else
  {
    return 0xFF;
  }
}
uint32_t StrToDec(uint8_t *hex)
{
  uint8_t *p1 = hex;
  uint32_t ret = 0;

  while(*p1 != '\0')
  {
    ret = ret * 10;

    if(*p1 >= '0' && *p1 <= '9')
    {
      ret += (*p1 - '0');
    }
    else if(*p1 >= 'a' && *p1 <= 'f')
    {
      ret += ((*p1 - 'a') + 0x0a);
    }
    else if(*p1 >= 'A' && *p1 <= 'F')
    {
      ret += ((*p1 - 'A') + 0x0a);
    }

    p1++;
  }

  return ret;
}
char *memstr(char *full_data, int full_data_len, char *substr)
{
  if (full_data == NULL || full_data_len <= 0 || substr == NULL)
  {
    return NULL;
  }

  if (*substr == '\0')
  {
    return NULL;
  }

  int sublen = strlen(substr);
  int i;
  char *cur = full_data;
  int last_possible = full_data_len - sublen + 1;

  for (i = 0; i < last_possible; i++)
  {
    if (*cur == *substr)
    {
      if (memcmp(cur, substr, sublen) == 0)
      {
        //found
        return cur;
      }
    }

    cur++;
  }

  return NULL;
}


/** @简介 - CRC校验函数
  * @参数 - 1.输入数据地址，2.数据长度
  * @返回 - CRC校验码
  */
uint16_t GetCRC16(uint8_t *dataAddr,uint16_t datalen)
{
  uint16_t crcValue = 0xFFFF;
  uint16_t i,k,j = 0;

  for(i = 0; i < datalen; i++)
  {
    j = dataAddr[i];
    crcValue ^= j;
    for(k = 0; k < 8; k++)
    {
      if(crcValue & 0x01)
      {
        crcValue >>= 1;
        crcValue ^= 0xA001;
      }
      else
      {
        crcValue >>= 1;
      }
    }
  }

  return crcValue;
}


/** @简介 - 累加和校验
  * @参数 - 1.输入数据地址，2.数据长度
  * @返回 - CRC校验码
  */
uint16_t GetSum16(uint8_t *dataAddr,uint16_t datalen)
{
  uint16_t Value = 0;
  uint16_t i = 0;

  Value = 0;
  for(i = 0; i < datalen; i++)
  {
    Value += dataAddr[i];
  }
  return Value;
}

