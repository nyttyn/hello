#include "main.h"
#include "set.h"
#include "usart.h"
#include "flash.h"
#include "x5043.h"
#include "cs5463.h"
#include "common.h"
#include "AppConfig.h"

#define _Debug_POINT_MOVE_NEXT(p) ((p) = ((p)+1 == Debug_uart->buffer_end ? Debug_uart->buffer : (p)+1))

osThreadId app_Debug_handle;
Debug_UART_HandleTypeDef *Debug_uart = NULL;

uint8_t capemflag = 0,casetflag = 0,nbflag = 0,flashflag = 0;
	
float Curr_zero = 0.0f;
float Curr_full = 0.0f;
float volt_Point1 = 0.0f;
float volt_Point2 = 0.0f;

/***************************************************************************************************
��������:	void HAL_Debug_Init(void)
��������:	��λ��У׼������ز�����ʼ��
��    ��:	��
***************************************************************************************************/
void HAL_Debug_Init(void)
{
  Debug_uart = pvPortMalloc(sizeof(Debug_UART_HandleTypeDef));
  Debug_uart->pWrite = Debug_uart->pRead = Debug_uart->buffer = pvPortMalloc(Debug_UART_BUF_LEN);
  Debug_uart->buffer_end = Debug_uart->buffer + Debug_UART_BUF_LEN;
  Debug_uart->huart = &App_Debug_huart;
  Debug_uart->remain_len = 0;
  __HAL_UART_ENABLE_IT(Debug_uart->huart, UART_IT_RXNE);
}

/***************************************************************************************************
��������:	int HAL_Debug_IRQHandler(void)
��������:	��λ��У׼�����жϴ�������
��    ��:	���ؽ�������
***************************************************************************************************/
int HAL_Debug_IRQHandler(void)
{
  if(Debug_uart && (__HAL_UART_GET_FLAG(Debug_uart->huart,UART_FLAG_RXNE) != RESET))
  {
    uint8_t data = READ_REG(Debug_uart->huart->Instance->DR);
    if(Debug_uart->remain_len == Debug_UART_BUF_LEN)
    {
      return -1;
    }
    *Debug_uart->pWrite = data;
    _Debug_POINT_MOVE_NEXT(Debug_uart->pWrite);
    Debug_uart->remain_len++;
    return -1;
  }
  return 0;
}

/***************************************************************************************************
��������:	size_t _Debug_AT_ReadLine(uint8_t* buf, size_t len)
��������:	��ȡѭ������������
��    ��:	���ؽ������ݳ���
***************************************************************************************************/
size_t _Debug_AT_ReadLine(uint8_t* buf, size_t len)
{
  size_t ret = 0, num = 0, _num = 0;
  uint8_t* s = Debug_uart->pRead;
  while( *s == '\n' || *s == '\r' )
  {
    _Debug_POINT_MOVE_NEXT(s);
    _num++;
  }
  while(len--)
  {
    *(buf++) = *s;
    _Debug_POINT_MOVE_NEXT(s);
    num++;
    if(*(buf-1) == '\n')
    {
      ret = num;
      Debug_uart->pRead = s;
      Debug_uart->remain_len -= _num + num;
      break;
    }
  }
  *(buf-1) = '\0';
  return ret;
}

size_t _Debug_CaPem_ReadLine(uint8_t* buf, size_t len)
{
  size_t ret = 0, num = 0;
  uint8_t* s = Debug_uart->pRead;

  HAL_Delay(1000);
  if(*s != 0)
  {
    for(uint16_t i = 0; i < len; i++)
    {
      *(buf+i) = *s;
      _Debug_POINT_MOVE_NEXT(s);
      num++;
      if(i == len-1)
      {
        ret = num;
        Debug_uart->pRead = s;
        Debug_uart->pWrite = Debug_uart->pRead;
        Debug_uart->remain_len = 0;
        break;
      }
    }
    *(buf-1) = '\0';
  }
	return ret;
}

uint16_t cntee(uint16_t count)
{
	uint16_t len1 = 0,len2 = 0,cnt = 0;
	len1 = count;
	len2= len1%4;						//����
	cnt =len1/4;						//����
	if(len2)	cnt +=1;
	return cnt;
}
						
/***************************************************************************************************
��������:	void Uart1RevHandle(void)
��������:	�������ݴ���
��    ��:	��
***************************************************************************************************/
size_t Uart1RevHandle(void)
{
  size_t len = 0,ret = false;
  char buf[20] = {0},data[100]= {0},datalong[1000]= {0};
  char *begin = NULL,*end = NULL;

  if(casetflag == 0x13)
    len = _Debug_CaPem_ReadLine((uint8_t*)datalong,BKPSRAM->caPemLen+10);
  else
    len=_Debug_AT_ReadLine((uint8_t*)data,100);

  if(len != 0 )
  {
		IWDG_Feed();
    if(casetflag == 0x13 &&(len == BKPSRAM->caPemLen+10))
    {
      if(datalong[0] == 's')
      {
        begin = strstr((char *)datalong,"+");
        end 	= strstr((char *)datalong,":");
      }
      if(begin == NULL || end == NULL || begin > end)
      {
        return ret;
      }
      else
      {
        begin +=strlen("+");
        memcpy(buf,begin,end-begin);
        end +=1;
        if(!strcmp(buf,"capem"))
        {
          memcpy((char *)&BKPSRAM->caPem,(char *)end,BKPSRAM->caPemLen);
          ret = true;
          casetflag = 0;
          return ret;
        }
      }
    }
    else
    {
      if( data[0] == 's')
      {
        begin = strstr((char *)data,"+");
        end 	= strstr((char *)data,":");
        if(begin == NULL || end == NULL || begin > end)
        {
          return ret;
        }
        else
        {
          begin +=strlen("+");
          memcpy(buf,begin,end-begin);
          end +=1;
          begin =strstr(end,"\r");
					IWDG_Feed();
          if(!strcmp(buf,"authkey"))
          {
            if(32 == (begin-end))
            {
              memcpy((char *)&BKPSRAM->authkey,(char *)end,32);
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"productkey"))
          {
            if(24 == (begin-end))
            {
              memcpy((char *)&BKPSRAM->productkey,(char *)end,24);
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"devicekey"))
          {
            if(24 == (begin-end))
            {
              memcpy((char *)&BKPSRAM->devicekey,(char *)end,24);
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"servername"))
          {
            BKPSRAM->serverNameLen = begin-end;
            memcpy((char *)&BKPSRAM->serverName,(char *)end,BKPSRAM->serverNameLen);
            ret = true;
            return ret;
          }
          else if(!strcmp(buf,"serverip"))
          {
            uint8_t iplen = 0;
            iplen = begin-end;
            if(iplen < 16)
            {
              memcpy((char *)&BKPSRAM->serverIP,(char *)end,iplen);
							BKPSRAM->serverIP[iplen] = '\0';
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"serverport"))
          {
						uint8_t portlen = begin-end;
            if(portlen == 4)
            {
              memcpy((char *)&BKPSRAM->serverPort,(char *)end,4);
							BKPSRAM->serverPort[portlen] = '\0';
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"capemlen"))
          {
            uint32_t d[1] = {0};
            if( 1 == sscanf(end,"%ld",&d[0]))
            {
              casetflag = 0x13;
              BKPSRAM->caPemLen = d[0];
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"light_lowlimit"))
          {
            uint32_t d[1] = {0};
            if( 1 == sscanf(end,"%ld",&d[0]))
            {
              BKPSRAM->light_lowlimit = d[0];
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"colortemp_lowlimit"))
          {
            uint32_t d[1] = {0};
            if( 1 == sscanf(end,"%ld",&d[0]))
            {
              BKPSRAM->colortemp_lowlimit = d[0];
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"colortemp_uplimit"))
          {
            uint32_t d[1] = {0};
            if( 1 == sscanf(end,"%ld",&d[0]))
            {
              BKPSRAM->colortemp_uplimit = d[0];
              ret = true;
            }
            return ret;
          }
          else if(!strcmp(buf,"dowmload"))
          {
            HAL_StatusTypeDef status = HAL_BUSY;
						if(FLASH_ReadWord((uint32_t)0x080400b4) != -1)  //0xff 
						{
						status = FLASH_Erase(((uint32_t)0x08040000),6);
						if(status) return ret;	
						}
						DataWriteFlash();	
						IWDG_Feed();
						HAL_Delay(200);
						DataReadFlash();
            return ret;
          }
        }
      }
      else if(data[0] == 'c')
      {
        begin = strstr((char *)data,"+");
        end 	= strstr((char *)data,"\r");
        if(begin == NULL || end == NULL || begin > end)
        {
          return ret;
        }
        else
        {
          begin +=strlen("+");
          memcpy(buf,begin,end-begin);
          if(!strcmp(buf,"curr_zero"))
          {
            CS5463_Handel();
            Curr_zero=fpower.fI;
            return ret;
          }
          else if(!strcmp(buf,"curr_full"))
          {
            CS5463_Handel();
            Curr_full=fpower.fI;
            return ret;
          }
          else if(!strcmp(buf,"curr_calib"))//�����ɼ����������̵�
          {
            float curr_shift = 0,curr_scale = 0,curr_calib = 0;
            curr_shift = Curr_zero;
            curr_scale = CURR_FULL/(Curr_full-Curr_zero);
            curr_calib = curr_scale*(fpower.fI - curr_shift);
            //if(fabs(curr_calib - fpower.fI)*100 <= curr_calib*10 )   //10%���
            //{
              BKPSRAM->Curr_Zero_Shift = curr_shift;
              BKPSRAM->Curr_Scale = curr_scale;
            //}
            return ret;
          }
          else if(!strcmp(buf,"curr_test"))
          {
            CS5463_Handel();
						BKPSRAM->Curr_Calib = BKPSRAM->Curr_Scale*(fpower.fI - BKPSRAM->Curr_Zero_Shift);
            return ret;
          }
          else if(!strcmp(buf,"calib_download"))
          {
						FLASH_Erase(((uint32_t)0x08060000),7);
						uint8_t buf[20] = {0};	
						sprintf((char*)buf,"%f",BKPSRAM->Curr_Zero_Shift);
						FLASH_Write((uint32_t)0x08060004,(int32_t*)buf,1);
						sprintf((char*)buf,"%f",BKPSRAM->Curr_Scale);
						FLASH_Write((uint32_t)0x08060008,(int32_t*)buf,1);
						sprintf((char*)buf,"%f",BKPSRAM->Volt_Zero_Shift);
						FLASH_Write((uint32_t)0x08060010,(int32_t*)buf,1);
						sprintf((char*)buf,"%f",BKPSRAM->Volt_Scale);
						FLASH_Write((uint32_t)0x08060014,(int32_t*)buf,1);
            return ret;
          }
          else if(!strcmp(buf,"volt_Point1"))
          {
            CS5463_Handel();
            volt_Point1=fpower.fV;
            return ret;
          }
          else if(!strcmp(buf,"volt_Point2"))
          {
            CS5463_Handel();
            volt_Point2=fpower.fV;
            return ret;
          }
          else if(!strcmp(buf,"volt_calib"))		//��ѹֵ�̶��ɵ�2��
          {
						float volt_shift = 0,volt_scale = 0,volt_calib = 0;
						volt_shift = (VOLT_POINT2*volt_Point1 - VOLT_POINT1*volt_Point2)/(VOLT_POINT2 - VOLT_POINT1);
						volt_scale = (VOLT_POINT2 - VOLT_POINT1)/(volt_Point2 - volt_Point1);
						volt_calib = volt_scale*(fpower.fV - volt_shift);
            //if(fabs(volt_calib - fpower.fV)*100 <= volt_calib*10)//10%���
            //{
							BKPSRAM->Volt_Zero_Shift = volt_shift;
							BKPSRAM->Volt_Scale = volt_scale;
            //}
            return ret;
          }
          else if(!strcmp(buf,"volt_test"))
          {
            CS5463_Handel();
						BKPSRAM ->Volt_Calib = BKPSRAM->Volt_Scale*(fpower.fV + BKPSRAM->Volt_Zero_Shift);
            return ret;
          }
        }
      }
    }
  }
  return ret;
	//HAL_UART_Transmit_IT(Debug_uart->huart, data, strlen(data));
}

/***************************************************************************************************
��������:	void CurrCalibDownload(float value1,float value2)
��������:	����У׼�����洢�����Ư��ֵ�ͱ���ϵ����
��    ��:	��
***************************************************************************************************/
void CurrCalibDownload(float value1,float value2)
{
  uint8_t buf[10] = {0};
  sprintf((char*)buf,"%f",value1);
  WR_X5043_mem(WRITE_L,0x10,buf,5);
	while((RD_EE_Status()&0x01)==0x01);
	//WR_X5043_mem(WRITE_L,0x10,buf,5);
	//while((RD_EE_Status()&0x01)==0x01);
  HAL_Delay(200);
  IWDG_Feed();
  memset(buf,0,10);
  sprintf((char*)buf,"%f",value2);
  WR_X5043_mem(WRITE_L,0x15,buf,5);
	while((RD_EE_Status()&0x01)==0x01);
	//WR_X5043_mem(WRITE_L,0x15,buf,5);
}

/***************************************************************************************************
��������:	void GetCurrCalib(float value1,float value2)
��������:	����У׼�����洢�����Ư��ֵ�ͱ���ϵ����
��    ��:	��
***************************************************************************************************/
void GetCurrCalib(void)
{
  uint8_t buf[10] = {0};
  RD_X5043_mem(READ_L,0x10,buf,5);
  sscanf((char*)buf,"%f",&BKPSRAM->Curr_Zero_Shift);
  memset(buf,0,10);
  HAL_Delay(200);
  RD_X5043_mem(READ_L,0x15,buf,5);
  sscanf((char*)buf,"%f",&BKPSRAM->Curr_Scale);
}

/***************************************************************************************************
��������:	void VoltCalibDownload(void)
��������:	��ѹУ׼�����洢�����Ư��ֵ�ͱ���ϵ����
��    ��:	��
***************************************************************************************************/
void VoltCalibDownload(float value1,float value2)
{
  uint8_t buf[10] = {0};
  sprintf((char*)buf,"%f",value1);
  WR_X5043_mem(WRITE_L,0x20,buf,5);
	while((RD_EE_Status()&0x01)==0x01);
	//WR_X5043_mem(WRITE_L,0x20,buf,5);
  HAL_Delay(200);
  IWDG_Feed();
  memset(buf,0,10);
  sprintf((char*)buf,"%f",value2);
  WR_X5043_mem(WRITE_L,0x25,buf,5);
	while((RD_EE_Status()&0x01)==0x01);
	//WR_X5043_mem(WRITE_L,0x25,buf,5);
}

/***************************************************************************************************
��������:	void GetVoltCalib(void)
��������:	��ȡ��ѹУ׼�����洢�����Ư��ֵ�ͱ���ϵ����
��    ��:	��
***************************************************************************************************/
void GetVoltCalib(void)
{
  uint8_t buf[10] = {0};
  RD_X5043_mem(READ_L,0x20,buf,5);
  sscanf((char*)buf,"%f",&BKPSRAM->Volt_Zero_Shift);
  memset(buf,0,10);
  HAL_Delay(200);
  RD_X5043_mem(READ_L,0x25,buf,5);
  sscanf((char*)buf,"%f",&BKPSRAM->Volt_Scale);
}
/***************************************************************************************************
��������:	void SetKeyTask(void const * argument)
��������:	���ò�����У׼����
��    ��:	��
***************************************************************************************************/
void SetKeyTask(void const * argument)
{
  for(;;)
  {
    IWDG_Feed();
    Uart1RevHandle();
		osDelay(1000);
  }
}
