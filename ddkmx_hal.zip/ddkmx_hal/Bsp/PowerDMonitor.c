#include "stm32f4xx_hal.h"
#include "PowerDMonitor.h"
#include "x5043.h"
#include "cs5463.h"

uint8_t  array_bk0[16] = {0};                        				   //写入X5043的数据存储区0
uint8_t  array_bk1[16] = {0};                        				   //写入X5043的数据存储区1
uint8_t  array_bk2[16] = {0};                        				   //写入X5043的数据存储区2
extern volatile uint8_t  mark_array_bk0;                       //数据array修改标志:0-修改结束,1-正在修改
extern volatile uint8_t  mark_array_bk1;                       //数据array修改标志:0-修改结束,1-正在修改
extern volatile uint8_t  mark_array_bk2;                       //数据array修改标志:0-修改结束,1-正在修改

/***************************************************************************************************
函数名称:	void EXTI_IRQHandler(void)  
功能描述:	电源监测中断程序
输    入：无
返    回:	无
***************************************************************************************************/
void EXTI_IRQHandler(void)  
{
  if(mark_array_bk0==0)
  {
    WR_X5043_mem(WRITE_H,0x00,array_bk0,16);             //存储区0数据写入X5043
    WR_X5043_mem(WRITE_H,0x40,array_bk0,16);             //存储区0数据写入X5043
    WR_X5043_mem(WRITE_H,0x80,array_bk0,16);             //存储区0数据写入X5043
  }
  else if(mark_array_bk1==0)
  {
    WR_X5043_mem(WRITE_H,0x00,array_bk1,16);             //存储区1数据写入X5043
    WR_X5043_mem(WRITE_H,0x40,array_bk1,16);             //存储区1数据写入X5043
    WR_X5043_mem(WRITE_H,0x80,array_bk1,16);             //存储区1数据写入X5043
  }
  else if(mark_array_bk2==0)
  {
    WR_X5043_mem(WRITE_H,0x00,array_bk2,16);             //存储区2数据写入X5043
    WR_X5043_mem(WRITE_H,0x40,array_bk2,16);             //存储区2数据写入X5043
    WR_X5043_mem(WRITE_H,0x80,array_bk2,16);             //存储区2数据写入X5043
  }
}

/***************************************************************************************************
函数名称:	void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) 
功能描述:	外部中断回调函数
输    入：GPIO_Pin中断IO口
返    回:	无
***************************************************************************************************/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if(GPIO_Pin == GPIO_PIN_12)
  {
    EXTI_IRQHandler();
  }
}
