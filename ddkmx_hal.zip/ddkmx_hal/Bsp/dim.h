#ifndef   __DIM_H
#define   __DIM_H

#define   JDQ_PORT        GPIOB                           //控制继电器的引脚端口
#define   JDQ_PIN         GPIO_PIN_10                     //控制继电器的引脚
#define   GYJC_PORT       GPIOB                           //控制继电器的引脚端口
#define   GYJC_PIN        GPIO_PIN_11                     //控制继电器的引脚
#define   JDQ_GPIO_ON  		HAL_GPIO_WritePin(JDQ_PORT,JDQ_PIN,GPIO_PIN_RESET)
#define   JDQ_GPIO_OFF  	HAL_GPIO_WritePin(JDQ_PORT,JDQ_PIN,GPIO_PIN_SET)

extern uint8_t  JDQ_Status;																//继电器状态

void Lamp_Init(void);                                     //路灯控制初始化
void JDQ_ON(void);                                        //继电器控制引脚=0,通电
void JDQ_OFF(void);                                       //继电器控制引脚=1,断电
void SetPWR_Duty(uint8_t Per);
void SetCTP_Duty(uint16_t Per);  //路灯调色温PWM

#endif
