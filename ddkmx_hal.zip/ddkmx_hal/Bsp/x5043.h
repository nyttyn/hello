#ifndef   __X5043_H
#define   __X5043_H

#define  READ_L          0x03                             //读x5043存储器低位地址命令(0000 A8011)
#define  READ_H          0x0b                             //读x5043存储器高位地址命令(0000 A8011)
#define  WRITE_L         0x02                             //写x5043存储器低位地址命令(0000 A8010)
#define  WRITE_H         0x0a                             //写x5043存储器高位地址命令(0000 A8010)

void X5043_Init(void);                                    //X5043初始化
unsigned char RD_EE_Status(void);                         //读x5043状态寄存器
void WR_EE_Status(unsigned char dat);                     //写x5043状态寄存器
void RD_X5043_mem(unsigned char mem_ad1,unsigned char mem_ad2,unsigned char *ptr,unsigned char n);
//读X5043存储器
void WR_X5043_mem(unsigned char mem_ad1,unsigned char mem_ad2,unsigned char *ptr,unsigned char n);
//写X5043存储器

#endif
