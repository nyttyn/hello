#ifndef   __DS1302_H
#define   __DS1302_H

extern unsigned char  Time_R[8];
extern unsigned char  Time_W[8];
void DS1302_Init(void);                                   //DS1302初始化
void ReadTime(void);                                      //读取DS1302时钟
void SetTime(void);                                       //设置DS1302时钟

#endif
