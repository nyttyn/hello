#include "main.h"
#include "flash.h"
#include "appInit.h"
#include "set.h"

/***************************************************************************************************
函数名称:	HAL_StatusTypeDef FLASH_Erase(uint32_t WriteAddr,uint16_t sector)
功能描述:	擦除flash扇区
输    入：需要擦除flash扇区的起始地址
返    回:	擦除状态
***************************************************************************************************/
HAL_StatusTypeDef FLASH_Erase(uint32_t WriteAddr,uint16_t sector)
{
  FLASH_EraseInitTypeDef FlashEraseInit;
  HAL_StatusTypeDef FlashStatus=HAL_BUSY;
  uint32_t SectorError=0;
  if(WriteAddr<FLASH_USER_START_ADDR||WriteAddr%4) return FlashStatus=HAL_ERROR; //非法地址
	
  HAL_FLASH_Unlock(); //解锁
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | 
                          FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);
  FlashEraseInit.TypeErase=FLASH_TYPEERASE_SECTORS; //类型扇区擦除
  FlashEraseInit.Sector=sector; //要擦除的扇区
  FlashEraseInit.NbSectors=1; //一次只擦除一个扇区
  FlashEraseInit.VoltageRange=FLASH_VOLTAGE_RANGE_3;
  if(HAL_FLASHEx_Erase(&FlashEraseInit,&SectorError)!=HAL_OK)
  {
    //break;
  }
  FlashStatus=FLASH_WaitForLastOperation(1000); //等待上次操作完成
  HAL_FLASH_Lock(); //上锁
  return FlashStatus;
}

/***************************************************************************************************
函数名称:	void FLASH_Write(uint32_t WriteAddr,int32_t *pBuffer,uint32_t NumToWrite)
功能描述:	保存数据至FLASH
输    入：WriteAddr保存地址，pBuffer需要保存的数据，NumToWrite保存数据长度
返    回:	擦除状态
***************************************************************************************************/
void FLASH_Write(uint32_t WriteAddr,int32_t *pBuffer,uint32_t NumToWrite)
{
  uint32_t endaddr=0;
  endaddr=WriteAddr+NumToWrite*4;
  HAL_FLASH_Unlock();
  while(WriteAddr<endaddr)
  {
    if(HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD,WriteAddr,*pBuffer)!=HAL_OK)
    {
      break;
    }
    WriteAddr+=4;
    pBuffer++;
  }
  HAL_FLASH_Lock();
}


/***************************************************************************************************
函数名称:	int32_t FLASH_ReadWord(uint32_t faddr)
功能描述:	读取指定地址的字(32 位数据)
输    入：faddr读地址
返    回:	读取的字(32位数据)
***************************************************************************************************/
int32_t FLASH_ReadWord(uint32_t faddr)
{
  return *(uint32_t*)faddr;
}

/***************************************************************************************************
函数名称:	void FLASH_Read(uint32_t ReadAddr,int32_t *pBuffer,uint32_t NumToRead)
功能描述:	从指定地址开始读出指定长度的数据
输    入：ReadAddr读地址，pBuffer数据指针，NumToRead字(32 位)数
返    回:	读取的字(32位数据)
***************************************************************************************************/
void FLASH_Read(uint32_t ReadAddr,int32_t *pBuffer,uint32_t NumToRead)
{
  uint8_t i;
  for(i=0; i<NumToRead; i++)
  {
		//*(pBuffer++)=FLASH_ReadWord(ReadAddr);
    pBuffer[i]=FLASH_ReadWord(ReadAddr);//读取 4 个字节.
    ReadAddr+=4;//偏移 4 个字节.
  }
}

/***************************************************************************************************
函数名称:	void DataWriteFlash(void)
功能描述:	写数据至FLASH
输    入：无
返    回:	无
***************************************************************************************************/
void DataWriteFlash(void)
{
	uint8_t cnt = 0;
	int32_t data = 0x12;
	FLASH_Write((uint32_t)0x08040004,&BKPSRAM->serverNameLen,1);
	FLASH_Write((uint32_t)0x08040008,&BKPSRAM->caPemLen,1);
	FLASH_Write((uint32_t)0x08040010,&BKPSRAM->light_lowlimit,1);
	FLASH_Write((uint32_t)0x08040014,&BKPSRAM->colortemp_uplimit,1);
	FLASH_Write((uint32_t)0x08040018,&BKPSRAM->colortemp_lowlimit,1);		
	FLASH_Write((uint32_t)0x08040020,(int32_t *)BKPSRAM->authkey,8);
	FLASH_Write((uint32_t)0x08040040,(int32_t *)BKPSRAM->productkey,6);
	FLASH_Write((uint32_t)0x08040060,(int32_t *)BKPSRAM->devicekey,6);
	cnt = cntee(BKPSRAM->serverNameLen);
	FLASH_Write((uint32_t)0x08040080,(int32_t *)BKPSRAM->serverName,cnt);
	FLASH_Write((uint32_t)0x080400a0,(int32_t *)BKPSRAM->serverIP,4);
	FLASH_Write((uint32_t)0x080400b0,(int32_t *)BKPSRAM->serverPort,1);	
	FLASH_Write((uint32_t)0x080400b4,&data,1);
	cnt = 0;
	cnt = cntee(BKPSRAM->caPemLen);						
	FLASH_Write((uint32_t)0x08040100,(int32_t *)BKPSRAM->caPem,cnt);
	FLASH_Write((uint32_t)0x08040004,&BKPSRAM->serverNameLen,1);
}

/***************************************************************************************************
函数名称:	void DataReadFlash(void)
功能描述:	从FLASH扇区6读取数据
输    入：无
返    回:	无
***************************************************************************************************/
void DataReadFlash(void)
{
	BKPSRAM->caPemLen = 0;
	BKPSRAM->serverNameLen = 0;
  memset(&BKPSRAM->authkey,0,50);
  memset(&BKPSRAM->productkey,0,50);
  memset(&BKPSRAM->devicekey,0,50);
  memset(&BKPSRAM->serverName,0,30);
  memset(&BKPSRAM->serverIP,0,16);
  memset(&BKPSRAM->serverPort,0,10);
  memset(&BKPSRAM->caPem,0,1000);
	BKPSRAM->caPemLen = 0;
	BKPSRAM->serverNameLen = 0;
  BKPSRAM->light_lowlimit = 0;
  BKPSRAM->colortemp_uplimit = 0;
  BKPSRAM->colortemp_lowlimit = 0;

  FLASH_Read((uint32_t)0x08040004,&BKPSRAM->serverNameLen,1);
  if(BKPSRAM->serverNameLen == -1) BKPSRAM->serverNameLen = 40;
	
	FLASH_Read((uint32_t)0x08040008,&BKPSRAM->caPemLen,1);
  if(BKPSRAM->caPemLen == -1) BKPSRAM->caPemLen = 1000;

  FLASH_Read((uint32_t)0x08040010,&BKPSRAM->light_lowlimit,1);
	if(BKPSRAM->light_lowlimit == -1)BKPSRAM->light_lowlimit=10;
	
  FLASH_Read((uint32_t)0x08040014,&BKPSRAM->colortemp_uplimit,1);
	if(BKPSRAM->colortemp_uplimit == -1)BKPSRAM->colortemp_uplimit=6500;
	
  FLASH_Read((uint32_t)0x08040018,&BKPSRAM->colortemp_lowlimit,1);
	if(BKPSRAM->colortemp_lowlimit == -1)BKPSRAM->colortemp_lowlimit=2700;
		
  FLASH_Read((uint32_t)0x08040020,(int32_t*)BKPSRAM->authkey,8);
  FLASH_Read((uint32_t)0x08040040,(int32_t*)BKPSRAM->productkey,6);
  FLASH_Read((uint32_t)0x08040060,(int32_t*)BKPSRAM->devicekey,6);
  FLASH_Read((uint32_t)0x08040080,(int32_t *)BKPSRAM->serverName,cntee(BKPSRAM->serverNameLen));
  FLASH_Read((uint32_t)0x080400a0,(int32_t *)BKPSRAM->serverIP,4);
	for(uint8_t i =0;i<16;i++)
	{
		if(BKPSRAM->serverIP[i] == 0xff)
		{
			BKPSRAM->serverIP[i] = '\0';
			break;
		}
	}
	FLASH_Read((uint32_t)0x080400b0,(int32_t *)BKPSRAM->serverPort,1);
	BKPSRAM->serverPort[5] = '\0';

  FLASH_Read((uint32_t)0x08040100,(int32_t*)BKPSRAM->caPem,cntee(BKPSRAM->caPemLen));
	//BKPSRAM->caPem[caPemLen] = '\0';
	if(BKPSRAM->serverIP[0] != 0 && BKPSRAM->serverIP[0] != 0xff && BKPSRAM->serverPort[0] == '8'
		&& BKPSRAM->caPem[0] != 0 && BKPSRAM->caPem[0] != 0xff)
	{
		capemflag = 0x55;
		nbflag = 0x34;
	}
}

/***************************************************************************************************
函数名称:	void DataReadFlash2(void)
功能描述:	从FLASH扇区7读取数据
输    入：无
返    回:	无
***************************************************************************************************/
void DataReadFlash2(void)
{
	char  temp1[5];
	FLASH_Read((uint32_t)0x08060004,(int32_t*)temp1,1);
	sscanf(temp1,"%f",&BKPSRAM->Volt_Zero_Shift);
	if(BKPSRAM->Curr_Zero_Shift == -1) BKPSRAM->Curr_Zero_Shift = 0;
	memset(temp1,0,5);
	FLASH_Read((uint32_t)0x08060008,(int32_t*)temp1,1);
	sscanf(temp1,"%f",&BKPSRAM->Curr_Scale);
	if(BKPSRAM->Curr_Scale == -1) BKPSRAM->Curr_Scale = 1;
	memset(temp1,0,5);
	FLASH_Read((uint32_t)0x08060010,(int32_t*)temp1,1);
	sscanf(temp1,"%f",&BKPSRAM->Volt_Zero_Shift);
	if(BKPSRAM->Volt_Zero_Shift == -1) BKPSRAM->Volt_Zero_Shift = 0;
	memset(temp1,0,5);
	FLASH_Read((uint32_t)0x08060014,(int32_t*)temp1,1);
	sscanf(temp1,"%f",&BKPSRAM->Volt_Scale);
	if(BKPSRAM->Volt_Scale == -1) BKPSRAM->Volt_Scale = 1;
}

