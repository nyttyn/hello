#include "stm32f4xx_hal.h"
#include "spi.h"
#include "gpio.h"

#define  WREN            0x06                                       //x5043写使能命令(0000 0110)
#define  WRDI            0x04                                       //x5043写禁止命令(0000 0100)
#define  RDSR            0x05                                       //读x5043状态寄存器命令(0000 0101)
#define  WRSR            0x01                                       //写x5043状态寄存器命令(0000 0001)
#define  X5043_Port      GPIOB                                      //X5043的GPIO口
#define  X5043_WP_Pin    GPIO_PIN_1                                 //WP的GPIO口线
#define  X5043_NSS_Pin   GPIO_PIN_12                                //NSS的GPIO口线
#define  X5043_SCK_Pin   GPIO_PIN_13                                //SCK的GPIO口线
#define  X5043_MISO_Pin  GPIO_PIN_14                                //MISO的GPIO口线
#define  X5043_MOSI_Pin  GPIO_PIN_15                                //MOSI的GPIO口线
#define  X5043_SPI       SPI2                                       //X5043使用SPI2口
#define  EN_CS()         HAL_GPIO_WritePin(X5043_Port,X5043_NSS_Pin,GPIO_PIN_RESET);//GPIO_ResetBits(X5043_Port,X5043_NSS_Pin);  //CS=0,片选使能
#define  UN_CS()         HAL_GPIO_WritePin(X5043_Port,X5043_NSS_Pin,GPIO_PIN_SET);//GPIO_SetBits(X5043_Port,X5043_NSS_Pin);    //CS=1,片选禁止
#define  EN_WP()         HAL_GPIO_WritePin(X5043_Port,X5043_WP_Pin,GPIO_PIN_RESET);//GPIO_ResetBits(X5043_Port,X5043_WP_Pin);   //WP=0,芯片写保护使能
#define  UN_WP()         HAL_GPIO_WritePin(X5043_Port,X5043_WP_Pin,GPIO_PIN_SET);//GPIO_SetBits(X5043_Port,X5043_WP_Pin);     //WP=1,芯片写保护禁止
#define  EN_WR()         WR_EE_Latch(WREN);                         //x5043写使能
#define  UN_WR()         WR_EE_Latch(WRDI);                         //x5043写禁止

uint8_t stm32_SPI2_SendData(uint8_t dat);                           //SPI2发送一个数据
void WR_EE_Latch(uint8_t dat);                                      //写x5043 Latch命令


/**SPI2 GPIO Configuration
PB12     ------> SPI2_NSS
PB13     ------> SPI2_SCK
PB14     ------> SPI2_MISO
PB15     ------> SPI2_MOSI
*/
/***************************************************************************************************
函数名称:	void X5043_Init(void) 
功能描述:	X5043 SPI 初始化
返    回:	无
***************************************************************************************************/
void X5043_Init(void)  //X5043初始化
{
  MX_SPI2_Init();    																											//CS=1,片选禁止
}

/***************************************************************************************************
函数名称:	uint8_t stm32_SPI2_SendData(uint8_t dat)
功能描述:	SPI2发送一个数据
返    回:	接收数据
***************************************************************************************************/
uint8_t stm32_SPI2_SendData(uint8_t dat)  
{
  uint16_t retry=0;
  while((SPI2->SR&1<<1)==0)								//等待发送区空
  {
    retry++;
    if(retry>0XFFFE)return 0;
  }
  SPI2->DR=dat;	 	  											//发送一个byte
  retry=0;
  while((SPI2->SR&1<<0)==0) 							//等待接收完一个byte
  {
    retry++;
    if(retry>0XFFFE)return 0;
  }
  return SPI2->DR;          							//返回收到的数据
}

/***************************************************************************************************
函数名称:	void WR_EE_Latch(uint8_t dat)
功能描述:	写x5043 Latch命令
返    回:	无
***************************************************************************************************/
void WR_EE_Latch(uint8_t dat)  
{
  EN_CS();
  stm32_SPI2_SendData(dat);
  UN_CS();
}

/***************************************************************************************************
函数名称:	uint8_t RD_EE_Status(void)
功能描述:	读x5043状态寄存器
返    回:	x5043状态
***************************************************************************************************/
uint8_t RD_EE_Status(void)  
{
  uint8_t  EE_Status;
  EN_CS();
  stm32_SPI2_SendData(RDSR);
  EE_Status=stm32_SPI2_SendData(0xff);
  UN_CS();
  return EE_Status;
}

/***************************************************************************************************
函数名称:	void WR_EE_Status(uint8_t dat)
功能描述:	写x5043状态寄存器
输    入：dat
返    回:	无
***************************************************************************************************/
void WR_EE_Status(uint8_t dat)  
{
  UN_WP();
  WR_EE_Latch(WREN);
  EN_CS();
  stm32_SPI2_SendData(WRSR);
  stm32_SPI2_SendData(dat);
  UN_CS();
  EN_WP();
}

/***************************************************************************************************
函数名称:	void RD_X5043_mem(uint8_t mem_ad1,uint8_t mem_ad2,uint8_t *ptr,uint8_t n)
功能描述:	读X5043存储器
输    入：mem_ad1存储器地址命令,mem_ad2存储器低8位地址,*ptr读取数据的指针,n读取数据的长度
返    回:	无
***************************************************************************************************/
void RD_X5043_mem(uint8_t mem_ad1,uint8_t mem_ad2,uint8_t *ptr,uint8_t n)
{
  uint8_t  i;
  EN_CS();
  stm32_SPI2_SendData(mem_ad1);
  stm32_SPI2_SendData(mem_ad2);
  for(i=0; i<n; i++)
  {
    *(ptr+i)=stm32_SPI2_SendData(0xff);
  }
  UN_CS();
}

/***************************************************************************************************
函数名称:	void WR_X5043_mem(uint8_t mem_ad1,uint8_t mem_ad2,uint8_t *ptr,uint8_t n)
功能描述:	写x5043存储器
输    入：mem_ad1存储器地址命令,mem_ad2存储器低8位地址,*ptr写入数据的指针,n写入数据的长度
返    回:	无
***************************************************************************************************/
void WR_X5043_mem(uint8_t mem_ad1,uint8_t mem_ad2,uint8_t *ptr,uint8_t n)
{
  uint8_t  i=0;
  UN_WP();
  WR_EE_Latch(WREN);
  EN_CS();
  stm32_SPI2_SendData(mem_ad1);
  stm32_SPI2_SendData(mem_ad2);
  for(i=n; i!=0; i--)
  {
    stm32_SPI2_SendData(*ptr);
    ptr++;
  }
  UN_CS();
  EN_WP();
}
