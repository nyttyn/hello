#ifndef   __CS5463_H
#define   __CS5463_H

typedef struct Power
{
  //unsigned int = uint32_t
  unsigned int  V;
  unsigned int  I;
  unsigned int  P;
  unsigned int  pf;
  unsigned int  T;
} POWER;

typedef struct fPower
{
  float  fV;
  float  fI;
  float  fP;
  float  fpf;
  float  fT;
  float  feps;
} fPOWER;

extern volatile POWER    power;
extern volatile fPOWER  fpower;                                //电量测量值结构变量(float)

void EnergyMeasureTask(void const * argument);
void CS5463_Init(void);                                            //CS5463初始化
void total_Init(void);
void CS5463_Handel(void);
#endif
