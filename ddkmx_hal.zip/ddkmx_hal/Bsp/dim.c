#include "main.h"
#include "dim.h"
#include "tim.h"

uint8_t  JDQ_Status=1;                                    //继电器状态:0-断电,1-通电
/***************************************************************************************************
函数名称:	void Lamp_Init(void) 
功能描述:	路灯控制初始化
输    入：无
返    回:	无
***************************************************************************************************/
void Lamp_Init(void)  
{
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_3);
}

/***************************************************************************************************
函数名称:	void JDQ_ON(void) 
功能描述:	继电器控制引脚=0,通电
输    入：无
返    回:	无
***************************************************************************************************/
void JDQ_ON(void)  
{
  JDQ_GPIO_ON;
  JDQ_Status=1;
}

/***************************************************************************************************
函数名称:	void JDQ_OFF(void) 
功能描述:	继电器控制引脚=1,断电
输    入：无
返    回:	无
***************************************************************************************************/
void JDQ_OFF(void)  
{
  JDQ_GPIO_OFF;
  JDQ_Status=0;
}

/***************************************************************************************************
函数名称:	void JDQ_Toggle(void) 
功能描述:	继电器的通断切换
输    入：无
返    回:	无
***************************************************************************************************/
void JDQ_Toggle(void)  
{
  if(JDQ_Status==0)
  {
    JDQ_ON();                                           
  }
  else
  {
    JDQ_OFF();                                          
  }
}

/***************************************************************************************************
函数名称:	void SetPWR_Duty(uint8_t Per)  
功能描述:	一路调节亮度PWM占空比配置
输    入：per目标亮度
返    回:	无
***************************************************************************************************/
void SetPWR_Duty(uint8_t Per)  //路灯调光PWM
{
  if(Per <= BKPSRAM->light_lowlimit)
  {
    __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,BKPSRAM->light_lowlimit*(60000/100)-1);									//Per=0(%)
    __HAL_TIM_SET_COUNTER(&htim2,0);
  }
  else if((Per>BKPSRAM->light_lowlimit)&&(Per<=100))
  {
    __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,Per*(60000/100)-1);	//0<Per≤100(%)
    __HAL_TIM_SET_COUNTER(&htim2,0);
  }
  else if(Per>100)
  {
    __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_2,60000-1);						//Per=100(%)
    __HAL_TIM_SET_COUNTER(&htim2,0);
  }
}

/***************************************************************************************************
函数名称:	void SetCTP_Duty(uint16_t Per)  
功能描述:	两路调节色温PWM占空比配置
输    入：per目标色温
返    回:	无
***************************************************************************************************/
void SetCTP_Duty(uint16_t Per)  //路灯调色温PWM
{
  if(Per <= BKPSRAM->colortemp_lowlimit )//低于下限
  {
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,10000-1);
    __HAL_TIM_SET_COUNTER(&htim3,0);
    __HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_3,1);
    __HAL_TIM_SET_COUNTER(&htim4,0);
  }
  else if(Per >= BKPSRAM->colortemp_uplimit)//高于上限
  {
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,1);
    __HAL_TIM_SET_COUNTER(&htim3,0);
    __HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_3,10000-1);
    __HAL_TIM_SET_COUNTER(&htim4,0);
  }
  else
  {
    uint16_t tim3duty,tim4duty=0;
    tim3duty=(BKPSRAM->colortemp_uplimit - Per)*100/(BKPSRAM->colortemp_uplimit - BKPSRAM->colortemp_lowlimit);
    tim4duty=100-tim3duty;
    __HAL_TIM_SET_COMPARE(&htim3,TIM_CHANNEL_2,tim3duty*(10000/100)-1);
    __HAL_TIM_SET_COUNTER(&htim3,0);
    __HAL_TIM_SET_COMPARE(&htim4,TIM_CHANNEL_3,tim4duty*(10000/100)-1);
    __HAL_TIM_SET_COUNTER(&htim4,0);
  }
}

/***************************************************************************************************
函数名称:	void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)  
功能描述:	TIM1回调函数
输    入：定时器
返    回:	无
***************************************************************************************************/
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM1)
  {
    HAL_IncTick();
  }
}
