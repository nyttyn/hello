#ifndef   __FLASH_H
#define   __FLASH_H

#define FLASH_USER_START_ADDR   	((uint32_t)0x08040000)
//#define FLASH_USER_START_ADDR   	((uint32_t)0x08040000)

void DataWriteFlash(void);
void DataReadFlash(void);
void DataReadFlash2(void);
HAL_StatusTypeDef FLASH_Erase(uint32_t WriteAddr,uint16_t sector);
void FLASH_Read(uint32_t ReadAddr,int32_t *pBuffer,uint32_t NumToRead);
void FLASH_Write(uint32_t WriteAddr,int32_t *pBuffer,uint32_t NumToWrite);
int32_t FLASH_ReadWord(uint32_t faddr);
#endif
