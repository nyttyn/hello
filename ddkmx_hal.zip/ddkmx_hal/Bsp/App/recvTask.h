#ifndef RECV_TASK_HH
#define RECV_TASK_HH

#include "appInit.h"

#define RECV_BUFF_LENGTH 1024

void AppRecvTask(void const * argument);

#endif
