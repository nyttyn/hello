
#ifndef SSL_TASK_HH
#define SSL_TASK_HH

#include <mbedtls.h>
#include "nbMod.h"

typedef enum
{
  SSL_STATUS_OFFLINE,
  SSL_STATUS_ONLINE
} SSLStatus_TypeDef;


extern mbedtls_ssl_context *ssl_context;
extern mbedtls_net_context mbedtls_ETH_ctx;

void SSL_Task(void const * argument);
void SSL_Init_One(void);
void SSL_Reinit(void);
void SSL_Connect(void);
void SSL_Reset(void);

#endif
