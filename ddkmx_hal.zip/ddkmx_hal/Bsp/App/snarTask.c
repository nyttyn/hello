
#include "snarTask.h"

time_t lastRecvTimeStamp;

static int _sonar_failed_num;

/***************************************************************************************************
��������:void AppSonarTask(void const * argument)
������������·̽������
��    ��:��
��    ��:��
***************************************************************************************************/
void AppSonarTask(void const * argument)
{
  _sonar_failed_num = 0;
  while(1)
  {
    if(BKPSRAM->_net_status == NET_ONLINE)
    {

      time_t now = time(NULL);

      if(now-lastRecvTimeStamp > SONAR_MIN_PERIOD)
      {
        if(_sonar_failed_num < SONAR_MAX_FAILED)
        {
          _sonar_failed_num++;
        }
        else
        {
          _sonar_failed_num = 0;
          //SSLReset();
        }
        lastRecvTimeStamp = now;
      }
    }
    osDelay(20*1000);
  }
}
