#ifndef SONAR_TASK_HH
#define SONAR_TASK_HH

#include <cmsis_os.h>
#include "userFunc.h"
#include "sslTask.h"

#define SONAR_MIN_PERIOD	120	//s
#define SONAR_MAX_FAILED	3

extern time_t lastRecvTimeStamp; //Global Time Stamp

void AppSonarTask(void const * argument);

#endif
