/*
** the Task of receiving data from ETH or 4G
*/
#include "procTask.h"
#include "cs5463.h"

static void _AppDecodeProperty(json_t* pjson);
static void _DecodeLocation(json_t* Location);
json_t *_NewLocation(void);
json_t *GetLightTimer(void);
/***************************************************************************************************
��������:	void AppProcTask(void const * argument)
��������:	NB͸�����մ�������
��    ��:	��
***************************************************************************************************/
void AppProcTask(void const * argument)
{
  while(1)
  {
    IWDG_Feed();
    osEvent evt = osMessageGet(appRecvQueueHandle, osWaitForever);
    if(evt.status == osEventMessage)
    {
      json_t *pjson =  evt.value.p;
      int ret = AppJsonDecode(pjson);
      switch(ret)
      {
      case DECODE_RETRAN:
        break;
      case DECODE_BACK:
        if(BKPSRAM->workingStatus == STATUS_ONLINE)
        {
          osMessagePut(appSendQueueHandle, (uint32_t)pjson, 0);
        }
        else
        {
          json_object_clear(pjson);
          json_decref(pjson);
        }
        break;
      case DECODE_ERROR:
      case DECODE_DONE:
        json_object_clear(pjson);
        json_decref(pjson);
        break;
      }
    }
  }
}

/***************************************************************************************************
��������:	DecodeRet_TypeDef AppJsonDecode(json_t* pjson)
��������:	NB͸�����մ�������
��    �룺����pjson
��    ��:	��Ӧ����
***************************************************************************************************/
DecodeRet_TypeDef AppJsonDecode(json_t* pjson)
{
  DecodeRet_TypeDef ret = DECODE_ERROR;
  if(!json_is_string(json_object_get(pjson,productKey))||//���productKey��deviceKey
      !json_is_string(json_object_get(pjson,deviceKey)))
  {
    return ret = DECODE_ERROR;
  }
  else
  {
    const char *pstr = json_string_value(json_object_get(pjson,productKey));
    if(strlen(pstr)!=24)
    {
      return ret = DECODE_ERROR;
    }
    pstr = json_string_value(json_object_get(pjson,deviceKey));	
    if(strlen(pstr)!=24)
    {
      return ret = DECODE_ERROR;
    }
  }

  const char *pstr = json_string_value(json_object_get(pjson,cmdKey));//���cmdKey
  if(!pstr)
  {
    ret = DECODE_ERROR;
  }
  else
  {
    if(!strcmp(pstr,RequestAccess))//��Ȩ�������
    {
      if(!strcmp(json_string_value(json_object_get(pjson,deviceKey)),BKPSRAM->devicekey))
      {
        if(json_is_true(json_object_get(pjson,"accepted")))
        {
          BKPSRAM->accepted = true;
          BKPSRAM->workingStatus = STATUS_ONLINE;
          if(!(BKPSRAM->activated))
          {
            BKPSRAM->activated = true;
          }
          ret = DECODE_DONE;//Success
          const char *key;
          json_t *value;
          json_object_foreach(pjson,key,value)
          {
            if(!strcmp(key,"timeStamp"))
            {
              time_t t = json_integer_value(value);
              AppUpdateTime(t);
              lastRecvTimeStamp = t;
            }
          }
        }
        else
        {
          ret = DECODE_ERROR;//Joining Refused
        }
      }
      else
      {
        //TODO Retransmission
        ret = DECODE_RETRAN;
      }
    }
    else if(!strcmp(pstr,DelayComm))//�ӳ�ͨ�Ž���
    {
      //TODO delayComm
      ret = DECODE_DONE;
    }
    else if(!strcmp(pstr,Configure))//���ö�ȡ��������
    {
      if(!strcmp(json_string_value(json_object_get(pjson,deviceKey)),BKPSRAM->devicekey))
      {
        _AppDecodeProperty(pjson);
        ret = DECODE_BACK;
      }
      else
      {
        ret = DECODE_RETRAN;
      }
    }
    else if(!strcmp(pstr,Alarm))//������Ӧ����
    {
			BKPSRAM->AlarmCode = 0;   
      ret = DECODE_DONE;
    }
  }
  return ret;
}

/***************************************************************************************************
????:double roundone(double dVal,short iPlaces)
????:double????iPlaces???
?    ?:dVal????,iPlaces?????????
?    ?:??????????
***************************************************************************************************/
double roundone(double dVal,short iPlaces)
{
	char s[20];
	double dRetval;
	sprintf(s,"%.*lf",iPlaces,dVal);
	sscanf(s,"%lf",&dRetval);
	return (dRetval);
}

/***************************************************************************************************
��������:	void _AppDecodeProperty(json_t* pjson)
��������:	CONFIG����
��    �룺����pjson
��    ��:	��
***************************************************************************************************/
void _AppDecodeProperty(json_t* pjson)
{
  const char *key;
  json_t *value;
  uint8_t valid_frame = 0;
  json_object_foreach(pjson,key,value)
  {
    if(!strcmp(key,cmdKey))
    {
      continue;
    }
    else if(!strcmp(key,productKey))
    {
      continue;
    }
    else if(!strcmp(key,deviceKey))
    {
      continue;
    }
    else if(!strcmp(key,"timeStamp"))
    {
      time_t t = json_integer_value(value);
      AppUpdateTime(t);
      lastRecvTimeStamp = t;
      json_object_set_new(pjson,"timeStamp",json_integer(time(NULL)));
      valid_frame = 1;
      continue;
    }
    else
    {
      if(1 == valid_frame)
      {
        if(!strcmp(key,"activated"))
        {
          if(json_is_boolean(value))
          {
            if(json_is_true(value))
            {
              BKPSRAM->activated = true;
            }
            else
            {
              _Iot_Reset();
							_Iot_Init();
            }
          }
          else
          {
            json_object_set_new(pjson,"activated",json_boolean(BKPSRAM->activated));
          }
          continue;
        }
        else if(!strcmp(key,authKey))
        {
          json_object_set_new(pjson,authKey,json_string(BKPSRAM->authkey));
          continue;
        }
        else if(!strcmp(key,"lightLevel"))
        {
          if(json_is_integer(value))
          {
            BKPSRAM->LightLevel = json_integer_value(value);
            if(BKPSRAM->LightLevel > 0 && BKPSRAM->LightLevel <= 100)
            {
							if(JDQ_Status ==0 ) JDQ_ON();
              if(BKPSRAM->LightLevel < BKPSRAM->light_lowlimit)BKPSRAM->LightLevel = BKPSRAM->light_lowlimit;
								SetPWR_Duty(BKPSRAM->LightLevel);
            }
            else if(BKPSRAM->LightLevel == 0)
            {
							if(JDQ_Status == 1 ) JDQ_OFF();
            }
						BKPSRAM->AppParamsUp = 0x11;
            json_integer_set(value,BKPSRAM->LightLevel);
          }
          else
          {
            json_object_set_new(pjson,"lightLevel",json_integer(BKPSRAM->LightLevel));
          }
          continue;
        }
        else if(!strcmp(key,"colorTemp"))
        {
          if(json_is_integer(value))
          {
            BKPSRAM->ColorTemp = json_integer_value(value);
            if(NULL != BKPSRAM->ColorTemp)
              SetCTP_Duty(BKPSRAM->ColorTemp);
            json_integer_set(value,BKPSRAM->ColorTemp);
          }
          else
          {
            json_object_set_new(pjson,"colorTemp",json_integer(BKPSRAM->ColorTemp));
          }
          continue;
        }
        else if(!strcmp(key,"lightTimerList"))
        {
          if(json_is_array(value))
          {
            BKPSRAM->stLightTimerNum = json_array_size(value);
            if(BKPSRAM->stLightTimerNum == 0) BKPSRAM->stLightTimerFlag = 0;
            else BKPSRAM->stLightTimerFlag = 0x12;
            for(int i=0; i<BKPSRAM->stLightTimerNum; i++)
            {
              json_t *t = json_array_get(value,i);
              {
                const char *timeStr = json_string_value(json_object_get(t,"time"));
                BKPSRAM->stLightTimerList[i].time = atoi(timeStr)*60+atoi(timeStr+3);
              }
              {
                const char *daysStr = json_string_value(json_object_get(t,"days"));
                char tmp = 0;
                for(char i=0; i<7; i++)
                {
                  if((daysStr[i]) == '1')
                    tmp = i+1;
                }
                BKPSRAM->stLightTimerList[i].days = tmp;
              }
              BKPSRAM->stLightTimerList[i].action = json_integer_value(json_object_get(t,"action"));
            }
          }
          else
          {
						json_object_set_new(pjson,"lightTimerList", GetLightTimer());
          }
          continue;
        }
        else if(!strcmp(key,"activePower"))
        {
          json_object_set_new(pjson,"activePower",json_real(roundone(BKPSRAM->ActivePower,0)));
          continue;
        }
        else if(!strcmp(key,"lightVolt"))
        {
          json_object_set_new(pjson,"lightVolt",json_real(roundone(BKPSRAM->Volt_Calib,0)));
          continue;
        }
        else if(!strcmp(key,"lightCurrent"))
        {
          json_object_set_new(pjson,"lightCurrent",json_real(roundone(BKPSRAM->Curr_Calib,3)));
          continue;
        }
        else if(!strcmp(key,"powerRatio"))
        {
          json_object_set_new(pjson,"powerRatio",json_real(roundone(BKPSRAM->PowerRadio,2)));
          continue;
        }
        else if(!strcmp(key,"workingStatus"))
        {
          json_object_set_new(pjson,"workingStatus",_workingStatus2json());
          continue;
        }
        else if(!strcmp(key,"power"))
        {
          if(json_is_integer(value))
          {
            BKPSRAM->Power = json_integer_value(value);
          }
          else
          {
            json_object_set_new(pjson,"power",json_integer(BKPSRAM->Power));
          }
          continue;
        }
        else if(!strcmp(key,"installTime"))
        {
          if(json_is_integer(value))
          {
            BKPSRAM->InstallTime = json_integer_value(value);
          }
          else
          {
            json_object_set_new(pjson,"installTime",json_integer(BKPSRAM->InstallTime));
          }
          continue;
        }
        else if(!strcmp(key,"serviceLife"))
        {
          if(json_is_integer(value))
          {
            BKPSRAM->ServiceLife = json_integer_value(value);
          }
          else
          {
            json_object_set_new(pjson,"serviceLife",json_integer(BKPSRAM->ServiceLife));
          }
          continue;
        }
        else if(!strcmp(key,"geoLocation"))
        {
          if(json_is_object(value))
          {
            _DecodeLocation(value);
          }
          else
          {
            json_object_set_new(pjson,"geoLocation",_NewLocation());
          }
          continue;
        }
        else
        {
          json_object_del(pjson,key);
          continue;
        }
      }
    }
  }
}

/***************************************************************************************************
��������:	void _DecodeLocation(json_t* location)
��������:	����λ�ý���
��    �룺location��γ��
��    ��:	��
***************************************************************************************************/
void _DecodeLocation(json_t* location)
{
  const char *key;
  json_t *value;
  json_object_foreach(location,key,value)
  {
    if(!strcmp(key,"longitude"))
    {
      if(json_is_real(value))
      {
        BKPSRAM->geoLocation.longitude = json_real_value(value);
      }
      else
      {
        json_object_set_new(location,"longitude",json_real(BKPSRAM->geoLocation.longitude));
      }
      continue;
    }
    else if(!strcmp(key,"latitude"))
    {
      if(json_is_real(value))
      {
        BKPSRAM->geoLocation.latitude = json_real_value(value);
      }
      else
      {
        json_object_set_new(location,"latitude",json_real(BKPSRAM->geoLocation.latitude));
      }
      continue;
    }
    else if(!strcmp(key,"text"))
    {
      if(json_is_string(value))
      {
        strncpy(BKPSRAM->geoLocation.text,json_string_value(value),32);
        BKPSRAM->geoLocation.text[32] = '\0';
      }
      else
      {
        json_object_set_new(location,"text",json_string(BKPSRAM->geoLocation.text));
      }
      continue;
    }
    else
    {
      json_object_del(location,key);
      continue;
    }
  }
}

/***************************************************************************************************
��������:	json_t *_NewLocation(void)
��������:	��������λ��json
��    �룺��
��    ��:	json����
***************************************************************************************************/
json_t *_NewLocation(void)
{
  json_t *location = json_object();
  json_object_set_new(location,"longitude",json_real(BKPSRAM->geoLocation.longitude));
  json_object_set_new(location,"latitude",json_real(BKPSRAM->geoLocation.latitude));
  json_object_set_new(location,"text",json_string(BKPSRAM->geoLocation.text));
  return location;
}

/***************************************************************************************************
��������:	json_t *GetLightTimer(void)
��������:	������ʱ���б�json
��    �룺��
��    ��:	json����
***************************************************************************************************/
json_t *GetLightTimer(void)
{
  json_t *arr = json_array();
  for(int i=0; i<BKPSRAM->stLightTimerNum; i++)
  {
    json_t *t = json_object();
    {
      uint16_t time = BKPSRAM->stLightTimerList[i].time;
      char str[6];
      snprintf(str,6,"%d:%d",time/60,time%60);
      json_object_set_new(t,"time",json_string(str));
    }
    {
      uint8_t d = BKPSRAM->stLightTimerList[i].days;
      char str[8];
      for(int i=0; i<7; i++)
      {
        str[i] = ((d & (1<<i)) == d)?'1':'0';
      }
      str[7]='\0';
      json_object_set_new(t,"days",json_string(str));
    }
    json_object_set_new(t,"action",json_integer(BKPSRAM->stLightTimerList[i].action));
    json_array_append_new(arr,t);
  }
	return arr;
}
