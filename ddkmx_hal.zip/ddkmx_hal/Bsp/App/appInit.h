#ifndef APP_INIT_HH
#define APP_INIT_HH

#include <cmsis_os.h>
#include <jansson.h>
#include <string.h>

#include "recvTask.h"
#include "sendTask.h"
#include "procTask.h"
#include "snarTask.h"
#include "AppConfig.h"
#include "userFunc.h"
#include "mbedtls.h"

extern osPoolId appMemPoolHandle;
extern osMessageQId appRecvQueueHandle;
extern osMessageQId appSendQueueHandle;
extern osThreadId appWifiTaskHandle;
extern osThreadId appRecvTaskHandle;
extern osThreadId appSendTaskHandle;
extern osThreadId appProcTaskHandle;
extern osThreadId SetTaskHandle;
typedef enum
{
  ITEM_ETH,
  ITEM_LTE,
  ITEM_WIFI,
  ITEM_PLC
} ITEM_TypeDef;

typedef struct
{
  ITEM_TypeDef type;
  json_t* data;
} QUEUE_ITEM_TypeDef;

void AppInit(void);

//Debug - FreeRTOS Malloc Failed CallBack
void vApplicationMallocFailedHook( void );

#endif
