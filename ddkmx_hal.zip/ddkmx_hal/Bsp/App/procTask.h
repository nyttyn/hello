#ifndef PROC_TASK_HH
#define PROC_TASK_HH

#include <cmsis_os.h>
#include <jansson.h>
#include <ctype.h>
#include "recvTask.h"
#include "sendTask.h"
#include "snarTask.h"
#include "dim.h"
//#include "NB.c"
typedef enum
{
  DECODE_DONE,	//done,not send back
  DECODE_BACK,	//done,but send back
  DECODE_ERROR,	//error,not send back
  DECODE_RETRAN	//need Retransmission
} DecodeRet_TypeDef;

void AppProcTask(void const * argument);
DecodeRet_TypeDef AppJsonDecode(json_t* pjson);
json_t *_NewLocation(void);
json_t *GetLightTimer(void);
double roundone(double dVal,short iPlaces);

#endif
