#ifndef SEND_TASK_HH
#define SEND_TASK_HH

#include "appInit.h"
#include "ssltask.h"

void AppSendTask(void const * argument);

#endif
