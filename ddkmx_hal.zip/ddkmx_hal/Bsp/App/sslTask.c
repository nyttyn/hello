
#include "sslTask.h"
#include "set.h"

#define SSL_SEED "silian_ssl_seed"

mbedtls_entropy_context *ssl_entropy;
mbedtls_ctr_drbg_context *ssl_ctr_drbg;
mbedtls_net_context mbedtls_ETH_ctx;
mbedtls_ssl_context *ssl_context;
mbedtls_ssl_config *ssl_conf;
mbedtls_x509_crt *ssl_cacert;

void SSL_Task(void const * argument)
{
  for(uint32_t n = 0;; n++)
  {
		IWDG_Feed();
    if( 0x34 == nbflag )
    {
      SSL_Init_One();
      nbflag = 0;
    }
    if(	BKPSRAM->_net_status == NET_OFFLINE )
    {
      if((n)%5 == 0)
      {
        if(NB_uart->state == STATE_TRANSMITION)
        {
          SSL_Reinit();
          SSL_Connect();
        }
      }
    }
    osDelay(1000);
  }
}

void SSL_Reset(void)
{
	BKPSRAM->workingStatus = STATUS_OFFLINE;
  mbedtls_ssl_close_notify( ssl_context );
  mbedtls_net_free( &mbedtls_ETH_ctx );
  mbedtls_ssl_free( ssl_context );
}

void SSL_Reinit(void)
{
  mbedtls_net_init( &mbedtls_ETH_ctx );
  mbedtls_ssl_init( ssl_context );
  mbedtls_ssl_setup( ssl_context, ssl_conf );
  mbedtls_ssl_set_hostname( ssl_context, BKPSRAM->serverName );
  mbedtls_ssl_set_bio( ssl_context, &mbedtls_ETH_ctx, mbedtls_net_send, mbedtls_net_recv, NULL );
}

void SSL_Connect(void)
{
  volatile int ret;

  ret = mbedtls_net_connect(&mbedtls_ETH_ctx,BKPSRAM->serverIP,BKPSRAM->serverPort,MBEDTLS_NET_PROTO_TCP);
  if(ret) return;

  while( ( ret = mbedtls_ssl_handshake( ssl_context ) ) != 0 )
  {
    if( ret != MBEDTLS_ERR_SSL_WANT_READ
        && ret != MBEDTLS_ERR_SSL_WANT_WRITE
      )
    {
      SSL_Reset();
      return;
    }
  }
  uint32_t flags;
  if( ( flags = mbedtls_ssl_get_verify_result( ssl_context ) ) != 0 )
  {
    uint8_t vrfy_buf[512];
    mbedtls_x509_crt_verify_info( (char *)vrfy_buf, sizeof( vrfy_buf ), "  ! ", flags );
    mbedtls_printf( "%s\n", vrfy_buf );
    SSL_Reset();
    return;
  }
  BKPSRAM->_net_status = NET_ONLINE;
}

#if defined(MBEDTLS_DEBUG_C)
static void mbedtls_debug( void *ctx, int level,
                           const char *file, int line,
                           const char *str )
{
  ((void) level);
  mbedtls_printf( "%s:%04d: %s", file, line, str );
}
#endif

void SSL_Init_One(void)
{
  BKPSRAM->_net_status = NET_OFFLINE;
  ssl_entropy = pvPortMalloc(sizeof(mbedtls_entropy_context));
  ssl_ctr_drbg = pvPortMalloc(sizeof(mbedtls_ctr_drbg_context));
  ssl_context = pvPortMalloc(sizeof(mbedtls_ssl_context));
  ssl_conf = pvPortMalloc(sizeof(mbedtls_ssl_config));
  ssl_cacert = pvPortMalloc(sizeof(mbedtls_x509_crt));
  mbedtls_entropy_init( ssl_entropy );
  mbedtls_ctr_drbg_init( ssl_ctr_drbg );
  mbedtls_ctr_drbg_seed( ssl_ctr_drbg, mbedtls_entropy_func, ssl_entropy,
                         (const unsigned char *) SSL_SEED, sizeof( SSL_SEED )-1 );
  mbedtls_x509_crt_init( ssl_cacert );
  mbedtls_x509_crt_parse( ssl_cacert, (const unsigned char *)
												BKPSRAM->caPem, BKPSRAM->caPemLen+1);
  mbedtls_ssl_config_init( ssl_conf );
  mbedtls_ssl_config_defaults( ssl_conf,
                               MBEDTLS_SSL_IS_CLIENT,
                               MBEDTLS_SSL_TRANSPORT_STREAM,
                               MBEDTLS_SSL_PRESET_DEFAULT );

  mbedtls_ssl_conf_authmode( ssl_conf, MBEDTLS_SSL_VERIFY_REQUIRED );
  mbedtls_ssl_conf_ca_chain( ssl_conf, ssl_cacert, NULL );
  mbedtls_ssl_conf_rng( ssl_conf, mbedtls_ctr_drbg_random, ssl_ctr_drbg );
#if defined(MBEDTLS_DEBUG_C)
  mbedtls_ssl_conf_dbg( ssl_conf, mbedtls_debug, stdout );
#endif
}
