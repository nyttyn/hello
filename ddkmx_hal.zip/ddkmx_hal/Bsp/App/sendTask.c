/*
** the Task of sending data to ETH or 4G or PLC
*/
#include "sendTask.h"
#include "cs5463.h"
/***************************************************************************************************
��������:int mbedtls_ssl_write_safe( const char *buf, size_t len )
��������:tls����
��    ��:buf���ܷ�������ָ�룬len���ܷ��͵����ݳ���
��    ��:���͵����ݳ���
***************************************************************************************************/
int mbedtls_ssl_write_safe( const char *buf, size_t len )
{
  for(long ln = len , pn = 0;
      ln -= (pn = mbedtls_ssl_write(ssl_context, (const unsigned char*)(buf += pn), ln));
     )
  {
    if(pn<0)return pn;
  }
  return len;
}

/***************************************************************************************************
��������:void AppSendTask(void const * argument)
����������������Ϣ������������
��    ��:��
��    ��:��
***************************************************************************************************/
void AppSendTask(void const * argument)
{
  unsigned m = 1,k = 1,n = 0,p = 0,q = 0;
  for(;;)
  {
    int ssl_write_ret;
    IWDG_Feed();
    osEvent evt = osMessageGet(appSendQueueHandle, 0);
    if(evt.status == osEventMessage)
    {
      json_t *pjson =  evt.value.p;
      //char *pstr = json_dumps(pjson, JSON_INDENT(0));
			char *pstr = json_dumps(pjson, JSON_INDENT(1) | JSON_COMPACT);
      if(pstr)
      {
        if(BKPSRAM->_net_status == NET_ONLINE)
        {
          ssl_write_ret = mbedtls_ssl_write_safe((const char*)pstr, strlen(pstr));
          printf("RETURN_SEND %d:%s",ssl_write_ret,pstr);//debug
        }
        vPortFree(pstr);
      }
      json_object_clear(pjson);
      json_decref(pjson);
    }
		
    if(BKPSRAM->_net_status == NET_ONLINE)
    {
      switch(BKPSRAM->workingStatus)
      {
      case STATUS_OFFLINE:
        if((n++)%20 == 0)
        {
          char *pstr = NULL;
          pstr = AppRequestAccess();						//��Ȩ����
          if(pstr)
          {
            ssl_write_ret = mbedtls_ssl_write_safe((const char*)pstr, strlen(pstr));
            printf("OFFLINE_SEND %d:%s",ssl_write_ret,pstr);//debug
            vPortFree(pstr);
          }
        }
        break;
      case STATUS_ONLINE:
        if(0x11 ==  BKPSRAM->AppParamsUp)
        {
          if((k++)%10 == 0)
          {
            BKPSRAM->AppParamsUp = 0;
            char *pstr = NULL;
            pstr = AppParamsUp();								//�����ϴ�
            if(pstr)
            {
              ssl_write_ret = mbedtls_ssl_write_safe((const char*)pstr, strlen(pstr));
              printf("ONLINE_SEND %d:%s",ssl_write_ret,pstr);//debug
              vPortFree(pstr);
            }
						//break;
          } 
        }
				IWDG_Feed();
        if(BKPSRAM->AlarmCode)
        {
          if((p++)%25 == 0)
          {
            q ++;
            if(q > 2)
            {
              q=0;
              BKPSRAM->AlarmCode = 0;
            }
            if(BKPSRAM->AlarmCode)
            {
              char *pstr = NULL;
              pstr = AppAlarm();										//����
              if(pstr)
              {
                ssl_write_ret = mbedtls_ssl_write_safe((const char*)pstr, strlen(pstr));
                printf("ONLINE_SEND %d:%s",ssl_write_ret,pstr);//debug
                vPortFree(pstr);
              }
            }
						break;
          }
        }

        if((m++)%50 == 0)//50s for heartbeat
        {
          char *pstr = NULL;
          pstr = AppHeartBeat();								//������
          if(pstr)
          {
            ssl_write_ret = mbedtls_ssl_write_safe((const char*)pstr, strlen(pstr));
            printf("ONLINE_SEND %d:%s",ssl_write_ret,pstr);//debug
            vPortFree(pstr);
          }
          //break;
        }
        break;
      default:
        break;
      }
    }
    osDelay(1000);
  }
}
