
#include "userFunc.h"
#include "procTask.h"
#include "ds1302.h"

/***************************************************************************************************
��������:char *AppRequestAccess(void)
��������:������Ȩ����json
��    ��:��
��    ��:��Ȩ�����ַ���
***************************************************************************************************/
char *AppRequestAccess(void)
{
  char *ret = NULL;
  json_t *root = json_object();
  json_object_set_new(root,cmdKey,json_string(RequestAccess));
  json_object_set_new(root,authKey,json_string(BKPSRAM->authkey));
  json_object_set_new(root,productKey,json_string(BKPSRAM->productkey));
  json_object_set_new(root,deviceKey,json_string(BKPSRAM->devicekey));
  json_object_set_new(root,"activated",json_boolean(BKPSRAM->activated));
  ret = json_dumps(root, JSON_INDENT(1) | JSON_COMPACT);
  json_object_clear(root);
  json_decref(root);

  return ret;
}

/***************************************************************************************************
��������:time_t time(time_t *p)
��������:��ȡ����ʱ���
��    ��:����ʱ���ָ��
��    ��:����ʱ���
***************************************************************************************************/
time_t time(time_t *p)
{
  struct tm stm;
  stm.tm_year = RTC_Bcd2ToByte(Time_R[6]) + 100; //since 2000
  stm.tm_wday = RTC_Bcd2ToByte(Time_R[5]);
  stm.tm_mon  = RTC_Bcd2ToByte(Time_R[4])-1;
  stm.tm_mday = RTC_Bcd2ToByte(Time_R[3]);
  stm.tm_hour = RTC_Bcd2ToByte(Time_R[2]);
  stm.tm_min  = RTC_Bcd2ToByte(Time_R[1]);
  stm.tm_sec  = RTC_Bcd2ToByte(Time_R[0]);
  return (p != NULL) ? (*p = mktime(&stm) - 28800) : (mktime(&stm) - 28800);
}

/***************************************************************************************************
��������:char *AppHeartBeat(void)
��������:����������json
��    ��:��
��    ��:�������ַ���
***************************************************************************************************/
char *AppHeartBeat(void)
{
  char *ret = NULL;
  json_t *root = json_object();

  json_object_set_new(root,cmdKey,json_string(HeartBeat));
  json_object_set_new(root,productKey,json_string(BKPSRAM->productkey));
  json_object_set_new(root,deviceKey,json_string(BKPSRAM->devicekey));
  json_object_set_new(root,"timeStamp",json_integer(time(NULL)));
  ret = json_dumps(root, JSON_INDENT(1) | JSON_COMPACT);
  json_object_clear(root);
  json_decref(root);
  return ret;
}

/***************************************************************************************************
��������:void AppUpdateTime(time_t timeStamp)
��������:���±���ʱ���
��    ��:ƽ̨ʱ���
��    ��:��
***************************************************************************************************/
void AppUpdateTime(time_t timeStamp)
{
  struct tm stm;
  timeStamp += 28800;
  time_t temp =time(NULL);
  if(difftime(timeStamp,temp)>60.0)
  {
    localtime_r( &timeStamp, &stm );
    Time_W[0] = RTC_ByteToBcd2(stm.tm_sec);
    Time_W[1] = RTC_ByteToBcd2(stm.tm_min);
    Time_W[2] = RTC_ByteToBcd2(stm.tm_hour);
    Time_W[3] = RTC_ByteToBcd2(stm.tm_mday);
    Time_W[4] = RTC_ByteToBcd2(stm.tm_mon + 1);
    Time_W[5] = RTC_ByteToBcd2(stm.tm_wday);
    Time_W[6] = RTC_ByteToBcd2(stm.tm_year - 100);
    SetTime();
  }
}

/***************************************************************************************************
��������:char *AppParamsUp(void)
��������:��������״̬json
��    ��:��
��    ��:json�ַ���
***************************************************************************************************/
char *AppParamsUp(void)
{
  char *ret = NULL;
  json_t *root = json_object();
  json_object_set_new(root,cmdKey,json_string(Configure));
  //json_object_set_new(root,authKey,json_string(BKPSRAM->authkey));
	json_object_set_new(root,deviceKey,json_string(BKPSRAM->devicekey));
  json_object_set_new(root,productKey,json_string(BKPSRAM->productkey));
  json_object_set_new(root,"timeStamp",json_integer(time(NULL)));
	json_object_set_new(root,"lightLevel",json_integer(BKPSRAM->LightLevel));
	json_object_set_new(root,"colorTemp",json_integer(BKPSRAM->ColorTemp));
	json_object_set_new(root,"activePower",json_real(roundone(BKPSRAM->ActivePower,0)));
  json_object_set_new(root,"lightVolt",json_real(roundone(BKPSRAM->Volt_Calib,0)));
  json_object_set_new(root,"lightCurrent",json_real(roundone(BKPSRAM->Curr_Calib,3)));
  json_object_set_new(root,"powerRatio",json_real(roundone(BKPSRAM->PowerRadio,2)));
  ret = json_dumps(root, JSON_INDENT(1) | JSON_COMPACT);
  json_object_clear(root);
  json_decref(root);
  return ret;
}

/***************************************************************************************************
��������:char *AppAlarm(void)
��������:��������json
��    ��:��
��    ��:����json�ַ���
***************************************************************************************************/
char *AppAlarm(void)
{
  char *ret = NULL;
  json_t *root = json_object();
  json_object_set_new(root,cmdKey,json_string(Alarm));
  json_object_set_new(root,productKey,json_string(BKPSRAM->productkey));
  json_object_set_new(root,deviceKey,json_string(BKPSRAM->devicekey));
  json_object_set_new(root,"alarmCode",_alarm2json());
  json_object_set_new(root,"timeStamp",json_integer(time(NULL)));
  ret = json_dumps(root, JSON_INDENT(0));
  json_object_clear(root);
  json_decref(root);
  return ret;
}

