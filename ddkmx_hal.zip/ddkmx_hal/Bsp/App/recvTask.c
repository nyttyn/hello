/*
** the Task of receiving data from ETH and 4G
*/
#include "recvTask.h"

/***************************************************************************************************
��������:void AppRecvTask(void const * argument)
��������:�ӷ�����������Ϣ����
��    ��:��
��    ��:��
***************************************************************************************************/
void AppRecvTask(void const * argument)
{
  static char recData[RECV_BUFF_LENGTH];
  for(;;)
  {
    IWDG_Feed();
    if(BKPSRAM->_net_status == NET_ONLINE)
    {
      int i = mbedtls_ssl_read( ssl_context, (unsigned char*)recData, RECV_BUFF_LENGTH );
      if(i>0)
      {
        json_error_t errorData;
        recData[i] = '\0';
        json_t* pjson = json_loads(recData,JSON_DISABLE_EOF_CHECK,&errorData);
        if(!pjson)
        {
          printf("ERR_RECV:%s",recData);
        }
        else
        {
          //put into the recvQueue
          osMessagePut(appRecvQueueHandle, (uint32_t)pjson, 0);
          //debug
          char *str = json_dumps(pjson, JSON_INDENT(1) | JSON_COMPACT);
          printf("RECV:%s",str);
          vPortFree(str);
        }
      }
      else
      {
      }
    }
    osDelay(300);
  }
}
