
#include "AppConfig.h"
#include "flash.h"
#include "dim.h"
#include "set.h"
#include "flash.h"
#include "x5043.h"
#include "cs5463.h"
#include "sslTask.h"
const char *cmdKey = "cmdKey";
const char *authKey = "authKey";
const char *productKey = "productKey";
const char *deviceKey = "deviceKey";
const char *RequestAccess = "RequestAccess";
const char *HeartBeat = "HeartBeat";
const char *DelayComm = "DelayComm";
const char *Configure = "Configure";
const char *Alarm = "Alarm";

BKPSRAM_TypeDef stBKPSRAM __attribute__((at(BKPSRAM_BASE)));
BKPSRAM_TypeDef *BKPSRAM ;

/***************************************************************************************************
��������:	void _Iot_Reset(void)
��������:	������ʼ��
��    ��:	��
***************************************************************************************************/
void _Iot_Reset(void)
{
  BKPSRAM->activated = false;
  BKPSRAM->accepted = false;
  BKPSRAM->RecTime = 0;
	BKPSRAM->LightLevel =100;
  BKPSRAM->ColorTemp = 3000;
  BKPSRAM->ActivePower = 0;
  BKPSRAM->Curr_Calib = 0;
  BKPSRAM->Volt_Calib = 0;
  BKPSRAM->PowerRadio = 0;
	BKPSRAM->Curr_Scale = 1;
	BKPSRAM->Curr_Zero_Shift = 0;
	BKPSRAM->Volt_Scale = 1;
	BKPSRAM->Volt_Zero_Shift = 0;
  BKPSRAM->AlarmCode = ALARM_NORMAL;
	SetPWR_Duty(BKPSRAM->LightLevel);
	SetCTP_Duty(BKPSRAM->ColorTemp);
  //BKPSRAM->workingStatus = STATUS_OFFLINE;
}

void _Iot_Init(void)
{
	BKPSRAM->Power = 0;
  BKPSRAM->InstallTime = 0;
  BKPSRAM->ServiceLife = 0;
  BKPSRAM->geoLocation.latitude = 0;
  BKPSRAM->geoLocation.longitude = 0;
  BKPSRAM->geoLocation.text[0] = '\0';
	BKPSRAM->stLightTimerNum = 0;
	BKPSRAM->stLightTimerFlag = 0;
  for(int i = 0; i < TIMER_MAX_NUM; i++)
  {
    BKPSRAM->stLightTimerList[i].time = 0;
    BKPSRAM->stLightTimerList[i].days = 0;
    BKPSRAM->stLightTimerList[i].action = 0;
  }
}
void ParamsInit(void)
{
	int32_t temp = 0;
  _Iot_Reset();
	JDQ_ON();
	JDQ_Status = 1;
	BKPSRAM->Curr_Calib = 0;
  BKPSRAM->Volt_Calib = 0;
	BKPSRAM->AppParamsUp = 0x11;
	BKPSRAM->_net_status = NET_OFFLINE;

	DataReadFlash2();
	FLASH_Read((uint32_t)0x080400b4,&temp,1);
	if(temp == 0x12)
	{
		DataReadFlash();
	}
}
/***************************************************************************************************
��������:	json_t *_workingStatus2json(void)
��������:	����״̬�ַ�������
��    ��:	����״̬�ַ���
***************************************************************************************************/
json_t *_workingStatus2json(void)
{
  switch(BKPSRAM->workingStatus)
  {
  case STATUS_ONLINE:
    return json_string("Online");
  case STATUS_DEBUG:
    return json_string("Debug");
  case STATUS_OVERVOLTAGE:
    return json_string("Overvoltage");
  case STATUS_OVERCURRENT:
    return json_string("Overcurrent");
  case STATUS_SECURITYALARM:
    return json_string("SecurityAlarm");
  case STATUS_FAULTALARM:
    return json_string("FaultAlarm");
  case STATUS_OFFLINE:
    break;
  }
  return 0;
}

/***************************************************************************************************
��������:	json_t *_alarm2json(void)
��������:	����״̬�ַ�������
��    ��:	����״̬�ַ���
***************************************************************************************************/
json_t *_alarm2json(void)
{
  switch(BKPSRAM->AlarmCode)
  {
  case ALARM_NORMAL:
    return json_string("Normal");						//�����޴�
  case ALARM_OVERVOLTAGE:
    return json_string("Overvoltage");			//��ѹ
  case ALARM_LAMPFAULT:
    return json_string("Lampboardfault");		//�ư廵
  case ALARM_POWERFAULT:
    return json_string("Powerfault");				//��Դ��
  case ALARM_CONTROLFAULT:
    return json_string("Contrlofult");			//��������
  case ALARM_PWMFAULT:
    return json_string("PWMfault");					//PWM��Χ��·��
  case ALARM_NBFAULT:
    return json_string("NBfault");					  //NB��
  }
  return 0;
}
