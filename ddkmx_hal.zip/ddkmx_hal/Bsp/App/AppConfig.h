
#ifndef APP_CONFIG_HH
#define APP_CONFIG_HH

#include <stdint.h>
#include <string.h>
#include <jansson.h>
#include "main.h"

#define DEFAULT_SERVER_IP "120.26.217.223"//"192.168.12.12"//
#define DEFAULT_SERVER_PORT "8018"



extern const char *AuthKey;
extern const char *ProductKey;//
extern const char *DeviceKey;
extern const char *cmdKey;
extern const char *authKey;
extern const char *productKey;
extern const char *deviceKey;

extern const char *RequestAccess;
extern const char *HeartBeat;
extern const char *DelayComm;
extern const char *Configure;
extern const char *Alarm;

/**
  * @brief Timer Definition
  */
typedef struct
{
  uint16_t time;	//minutes of day 0~1439
  uint8_t days;		//0~6bit:Monday~Sunday
  uint8_t action; //0,1~100

} Timer_TypeDef;
/*
typedef struct
{
  char ac8time[5];
  char ac8days[7];
  int8_t i8Action;
} time_TypeDef;*/
/**
  * @brief the length of Timer List
  */
#define TIMER_MAX_NUM 24

/**
  * @brief Geographical Position Definition
  */
typedef struct
{
  float longitude;
  float latitude;
  char text[33];//Street abbreviation 32chars+'\0'
} GeoLocation_TypeDef;

/**
  * @brief Alarm Definition
  */
typedef enum
{
  ALARM_NORMAL = 0,
  ALARM_OVERVOLTAGE,
  ALARM_LAMPFAULT,
  ALARM_POWERFAULT,
  ALARM_CONTROLFAULT,
  ALARM_PWMFAULT,
  ALARM_NBFAULT
} Alarm_TypeDef;
/**
  * @brief Work Status Definition
  */
typedef enum
{
  STATUS_ONLINE,
  STATUS_DEBUG,
  STATUS_OVERVOLTAGE,
  STATUS_OVERCURRENT,
  STATUS_SECURITYALARM,
  STATUS_FAULTALARM,
  STATUS_OFFLINE
} WorkStatus_TypeDef;

/**
  * @brief Net Status Definition
  */
typedef enum
{
  NET_OFFLINE,
  NET_ONLINE
} NetStatus_TypeDef;

/**
  * @brief Key Flag Definition
  */
typedef union
{
  struct
  {
    uint8_t akeyflag;
    uint8_t pkeyflag;
    uint8_t dkeyflag;
  } BIT;
  uint16_t CONTROL;
} KeyFlag_TypeDef;

/**
  * @brief BackUp SRAM 4Kbyte
  */
typedef struct
{
  /******���ò���*********/
  char authkey[50];
  char productkey[50];
  char devicekey[50];
  int32_t light_lowlimit;
  int32_t colortemp_uplimit;
  int32_t colortemp_lowlimit;
  float Curr_Zero_Shift;
  float Curr_Scale;
  float Curr_Calib;
  float Volt_Zero_Shift;
  float Volt_Scale;
  float Volt_Calib;
  /******ƽ̨ͨѶ����*********/
  bool activated;
  bool accepted;
  int64_t RecTime;
  int32_t LightLevel;
  int32_t ColorTemp;
  uint8_t stLightTimerNum;
  uint8_t stLightTimerFlag;
  Timer_TypeDef stLightTimerList[TIMER_MAX_NUM];
  float ActivePower;
  //float LightVolt;
  //float LightCurrent;
  float PowerRadio;
  WorkStatus_TypeDef workingStatus;
  int32_t Power;
  int64_t InstallTime;
  int32_t ServiceLife;
  GeoLocation_TypeDef geoLocation;
  int8_t AlarmCode;
  char serverName[30];
  char serverIP[16];//<=xxx.xxx.xxx.xxx +'\0'
  char serverPort[6];//<=xxxxx +'\0'
  char caPem[1000];//<=xxxxx +'\0'
  NetStatus_TypeDef _net_status;
  uint8_t AppParamsUp;
	int32_t caPemLen;
	int32_t serverNameLen;
} BKPSRAM_TypeDef;


extern BKPSRAM_TypeDef stBKPSRAM;
extern BKPSRAM_TypeDef *BKPSRAM ;

void _Iot_Reset(void);
void _Iot_Init(void);
void ParamsInit(void);
json_t *_alarm2json(void);
json_t *_workingStatus2json(void);


#endif
