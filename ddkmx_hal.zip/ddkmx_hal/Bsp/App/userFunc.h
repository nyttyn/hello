
#ifndef JSON_FUNC_HH
#define JSON_FUNC_HH

#include "main.h"
#include <jansson.h>
#include <time.h>
#include <string.h>

//extern RTC_HandleTypeDef hrtc;

char *AppRequestAccess(void);
char *AppHeartBeat(void);
char *AppParamsUp(void);
char *AppAlarm(void);
void AppUpdateTime(time_t timeStamp);

#endif
