#ifndef _COMMON_H_
#define _COMMON_H_

//#include "Nano103.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <float.h>
#include <limits.h>
#include <ctype.h>
#include <stdbool.h>
#include <time.h>
#include <stdint.h>






/* 全局宏定义配置  */

#define RECV_BUF_SIZE  512  //NB接收BUF大小


/* 调试信息处理 */
#define __DEBUG__   //调试总开关



#ifdef __DEBUG__
#define DEBUG(format,...) printf("******File: "__FILE__", Line: %05d******: \r\n"format"", __LINE__, ##__VA_ARGS__)
#else
#define DEBUG(format,...)
#endif

/* FIFO 基础结构定义，根据实际情况更改 */
#define Elem_Type        uint8_t

/* FIFO操作错误代码 */
#define FLAGS_OVERRUN 0x0001

/* FIFO结构体定义 */
typedef struct
{
  Elem_Type* buf;
  volatile  uint16_t write, read, size, free, flags;
} FIFO_Queue;

typedef enum
{
  STOP = 0,
  START,
  OK
} Flag_State;





/* 系统状态全局结构体定义 */


/******    时间结构体  ******/
typedef struct _Systime_TimeInfoType
{
  /* 秒 */
  uint8_t second;
  /* 分 */
  uint8_t minute;
  /* 小时 */
  uint8_t hour;
  /* 日期 */
  uint8_t date;
  /* 星期 */
  uint8_t weekday;
  /* 月份 */
  uint8_t month;
  /* 年份 */
  uint16_t year;
  /* 时间准确性 */
  bool  timeErr;
} strSysTime;



/* FIFO函数声明 */
void FIFOQueue_Init(FIFO_Queue *fifo, Elem_Type* fifobuf, uint16_t bufsize);
void FIFOQueue_Clear(FIFO_Queue *fifo);
extern int8_t   FIFOQueue_Put(FIFO_Queue *fifo, Elem_Type *data, uint32_t size);
extern int8_t   FIFOQueue_Get(FIFO_Queue *fifo, Elem_Type *data, uint32_t size);
extern uint16_t FIFOQueue_Status(FIFO_Queue *fifo);
extern uint16_t FIFOQueue_Free(FIFO_Queue *fifo);



extern void     *memcpy2(void *dest, const void *src, uint8_t count);
extern char     *StrToUpper(char *src);
extern void     ClearBuffer(uint8_t *p,  uint16_t size);
extern uint32_t str2int(const char *str);
extern uint8_t  hexstrToint64(uint8_t *str, uint64_t *ret);
extern void     int64Tohexstr(uint64_t num , uint8_t *hexstr);
extern uint8_t  hexstrToint8(uint8_t *str, uint8_t *ret);
extern void     int8Tohexstr(uint8_t num , uint8_t *hexstr);
extern uint8_t  HexToInt(uint8_t Hex);
extern uint32_t StrToDec(uint8_t *hex);
extern char     *memstr(char *full_data, int full_data_len, char *substr);
extern  uint16_t GetCRC16(uint8_t *dataAddr,uint16_t datalen);
extern  uint16_t GetSum16(uint8_t *dataAddr,uint16_t datalen);

#endif //__HXH_COMMON_H_

