#ifndef   __SET_H
#define   __SET_H

#define App_Debug_huart huart1
#define Debug_UART_BUF_LEN 2048*2
#define VOLT_POINT2 200.0f
#define VOLT_POINT1 190.0f
#define CURR_FULL 1.5f

typedef struct
{
  uint8_t* buffer;
  uint8_t* buffer_end;
  uint32_t remain_len;
  uint8_t* pWrite;
  uint8_t* pRead;
  UART_HandleTypeDef *huart;
} Debug_UART_HandleTypeDef;
/* USER CODE END Private defines */

extern uint8_t capemflag;
extern uint8_t nbflag;
extern uint8_t flashflag;

void HAL_Debug_Init(void);
int HAL_Debug_IRQHandler(void);
size_t _Debug_AT_ReadLine(uint8_t* buf, size_t len);
void SetKeyTask(void const * argument);
void CurrCalibDownload(float value1,float value2);
void VoltCalibDownload(float value1,float value2);
void GetCurrCalib(void);
void GetVoltCalib(void);
uint16_t cntee(uint16_t count);
#endif
