#include "main.h"
#include "spi.h"
#include "cs5463.h"
#include "x5043.h"
#include "ds1302.h"
#include "nbMod.h"
#include "dim.h"
#include "math.h"
#include "PowerDMonitor.h"

//CS5463内部寄存器读地址(寄存器读地址:高两位为00)
#define  WRITE              0x40  					//寄存器写地址:高两位为01
#define  CONFIG             0x00  					//配置寄存器(Default=0x000001,K=1)
#define  IDCoff             0x02  					//电流通道DC偏移量寄存器(Default=0x000000)
#define  Igain              0x04  					//电流通道增益寄存器(Default=0x400000=1.000)
#define  VDCoff             0x06  					//电压通道DC偏移量寄存器(Default=0x000000)
#define  Vgain              0x08  					//电压通道增益寄存器(Default=0x400000=1.000)
#define  CYCLE_COUNT        0x0A  					//周期计数寄存器(Default=0x000FA0=4000,1s)
#define  PulseRateE         0x0C  					//E1.E2.E3脉冲速率寄存器(Default=0x800000=1.00(2kHz@4.096MHz MCLK))
#define  Instant_CURRENT    0x0E  					//瞬时电流寄存器
#define  Instant_VOLT       0x10  					//瞬时电压寄存器
#define  Instant_POWER      0x12  					//瞬时功率寄存器
#define  Pactive            0x14  					//有功功率寄存器
#define  CURRENT_RMS        0x16  					//电流有效值(均方根值)寄存器
#define  VOLT_RMS           0x18  					//电压有效值(均方根值)寄存器
#define  STATUS             0x1E  					//状态寄存器(Default=0x800001)
#define  IACoff             0x20  					//电流通道AC偏移量寄存器(Default=0x000000)
#define  VACoff             0x22  					//电压通道AC偏移量寄存器(Default=0x000000)
#define  Mode               0x24  					//操作模式寄存器(Default=0x000000)
#define  Temperature        0x26  					//温度寄存器
#define  PowerFactor        0x32  					//功率因数寄存器
#define  MASK               0x34  					//中断屏蔽寄存器(Default=0x000000)
#define  Ctrl               0x38  					//控制寄存器(Default=0x000000)
#define  Qf                 0x3E  					//页寄存器(Default=0x00,write only)
#define  TGain              0x04  					//温度通道增益寄存器(Default=0x2F03C3=23.5073471)
#define  Toff               0x06  					//温度通道偏移量寄存器(Default=0xF3D35A=-0.0951126)
#define  CS5463_Port        GPIOA                  	//CS5463的GPIO口
#define  CS5463_RST_Pin     GPIO_PIN_0             	//RST的GPIO口线
#define  CS5463_NSS_Pin     GPIO_PIN_4             	//NSS的GPIO口线
#define  CS5463_SCK_Pin     GPIO_PIN_5             	//SCK的GPIO口线
#define  CS5463_MISO_Pin    GPIO_PIN_6             	//MISO的GPIO口线
#define  CS5463_MOSI_Pin    GPIO_PIN_7             	//MOSI的GPIO口线
#define  CS5463_E1_Port     GPIOB                  	//E1的GPIO口
#define  CS5463_E1_Pin      GPIO_PIN_0             	//E1的GPIO口线

#define  UN_CS()            HAL_GPIO_WritePin(CS5463_Port,CS5463_NSS_Pin,GPIO_PIN_SET)//GPIO_SetBits(CS5463_Port,CS5463_NSS_Pin);    //CS=1
#define  EN_CS()            HAL_GPIO_WritePin(CS5463_Port,CS5463_NSS_Pin,GPIO_PIN_RESET)//GPIO_ResetBits(CS5463_Port,CS5463_NSS_Pin);  //CS=0
#define  UN_RSTKZ()         HAL_GPIO_WritePin(CS5463_Port,CS5463_RST_Pin,GPIO_PIN_SET)//GPIO_SetBits(CS5463_Port,CS5463_RST_Pin);    //RST=1
#define  EN_RSTKZ()         HAL_GPIO_WritePin(CS5463_Port,CS5463_RST_Pin,GPIO_PIN_RESET)//GPIO_ResetBits(CS5463_Port,CS5463_RST_Pin);  //RST=0

volatile float     total_powerP;                   	//累计电能量float
volatile float     total_powerP_bk1;               	//累计电能量float
volatile float     total_powerP_bk2;               	//累计电能量float
volatile uint32_t  total_time;                     	//累计时间int32
volatile uint32_t  total_time_bk1;                 	//累计时间int32
volatile uint32_t  total_time_bk2;                 	//累计时间int32
volatile POWER    power;                           	//电量测量值结构变量(unsigned int)
volatile fPOWER  fpower;                           	//电量测量值结构变量(float)
static uint8_t  EE_ACgain_V_ERR;                   	//X5043电压通道AC增益校准值出错标志
static uint8_t  EE_ACgain_I_ERR;                   	//X5043电流通道AC增益校准值出错标志
volatile uint8_t   mark_total_powerP=0;            	//累计电能量float修改标志:0-修改结束,1-正在修改
volatile uint8_t   mark_total_powerP_bk1=0;        	//累计电能量float修改标志:0-修改结束,1-正在修改
volatile uint8_t   mark_total_powerP_bk2=0;        	//累计电能量float修改标志:0-修改结束,1-正在修改
volatile uint8_t   mark_total_time=0;              	//累计时间int32修改标志:0-修改结束,1-正在修改
volatile uint8_t   mark_total_time_bk1=0;          	//累计时间int32修改标志:0-修改结束,1-正在修改
volatile uint8_t   mark_total_time_bk2=0;          	//累计时间int32修改标志:0-修改结束,1-正在修改
volatile uint8_t   mark_array_bk0=0;               	//数据array修改标志:0-修改结束,1-正在修改
volatile uint8_t   mark_array_bk1=0;               	//数据array修改标志:0-修改结束,1-正在修改
volatile uint8_t   mark_array_bk2=0;               	//数据array修改标志:0-修改结束,1-正在修改
uint8_t   mark_total_Init_ERR=0;          				 //累计值初始值读取错误标志:0-正确,1-错误
uint8_t stm32_SPI1_SendData(uint8_t dat);           //SPI1发送一个数据
void CS5463_ACgain_Init(void);                      //初始化AC增益校准寄存器
unsigned int update_V(void);                        //读电压有效值:mV
unsigned int update_I(void);                        //读电流有效值:mA
unsigned int update_P(void);                        //读有功功率:mW
unsigned int update_pf(void);                       //读功率因数:百分比*10000
unsigned int update_T(void);                        //读温度值:℃*100
float foar(float ff,uint8_t *pp,uint8_t k);
unsigned short check_CRC16(unsigned char *dat,unsigned char cnt);
void Write_CS5463(unsigned char *ptr,unsigned char n);

/**SPI1 GPIO Configuration
PA4     ------> SPI1_NSS
PA5     ------> SPI1_SCK
PA6     ------> SPI1_MISO
PA7     ------> SPI1_MOSI
*/
/***************************************************************************************************
函数名称：void CS5463_Init(void)
功能描述：CS5463初始化
输    入：无
返    回：无
***************************************************************************************************/
void CS5463_Init(void)
{
  uint8_t  buf[5];
  EN_RSTKZ();
  UN_CS();
  MX_SPI1_Init();
  UN_RSTKZ();                                                        //RST=1
  HAL_Delay(100);
  //CS5463寄存器初始化
  buf[0]=0xff;              //***写SYNC0、SYNC1命令:CS5463串口重新初始化
  buf[1]=0xff;
  buf[2]=0xff;              //SYNC1=0xff
  buf[3]=0xfe;              //SYNC0=0xfe
  Write_CS5463(buf,4);
  buf[0]=0x5e;              //***写状态寄存器(Default=0x800001)
  buf[1]=0x80;              //DRDY位清零
  buf[2]=0x00;
  buf[3]=0x00;
  Write_CS5463(buf,4);
  buf[0]=0x40;              //***写配置寄存器(Default=0x000001)
  buf[1]=0x00;              //电流通道增益:00-10,01-50
  buf[2]=0x00;
  buf[3]=0x01;              //内部时钟分频=1
  Write_CS5463(buf,4);
  buf[0]=0x4a;              //***写周期计数寄存器(Default=0x000FA0=4000)
  buf[1]=0x00;
  buf[2]=0x0f;
  buf[3]=0xa0;              //N=4000,计算周期1秒
  Write_CS5463(buf,4);
  buf[0]=0x74;              //***写中断屏蔽寄存器:不激活INT引脚功能(Default=0x000000)
  buf[1]=0x00;
  buf[2]=0x00;
  buf[3]=0x00;
  Write_CS5463(buf,4);
  buf[0]=0x64;              //***写操作模式寄存器(Default=0x000000)
  buf[1]=0x00;
  buf[2]=0x00;
  buf[3]=0x61;              //开启HPF高通滤波器,开启IIR补偿滤波器,自动在线频率测量
  Write_CS5463(buf,4);
  CS5463_ACgain_Init();     //初始化AC增益校准寄存器
  buf[0]=0xe8;              //***启动转换命令:执行连续计算周期
  Write_CS5463(buf,1);
}

/***************************************************************************************************
函数名称：void power_update(void)
功能描述：更新电测值
输    入：无
返    回：无
***************************************************************************************************/
void power_update(void)  //
{
  power.V=update_V();                                     //读电压有效值:mV
  power.I=update_I();                                     //读电流有效值:mA
  power.P=update_P();                                     //读有功功率:mW
  power.pf=update_pf();                                   //读功率因数:百分比*10000
  //power.T=update_T();                                   //读温度值:℃*100
}

/***************************************************************************************************
函数名称：uint8_t stm32_SPI1_SendData(uint8_t dat)
功能描述：SPI1发送一个数据
输    入：dat发送数据
返    回：SPI接收数据
***************************************************************************************************/
uint8_t stm32_SPI1_SendData(uint8_t dat)
{
  uint16_t retry=0;
  while((SPI1->SR&1<<1)==0)								//等待发送区空
  {
    retry++;
    if(retry>0XFFFE)return 0;
  }
  SPI1->DR=dat;	 	  									//发送一个byte
  retry=0;
  while((SPI1->SR&1<<0)==0) 							//等待接收完一个byte
  {
    retry++;
    if(retry>0XFFFE)return 0;
  }
  return SPI1->DR;          							//返回收到的数据
}

/***************************************************************************************************
函数名称：void Write_CS5463(uint8_t *ptr,uint8_t n)
功能描述：写CS5463数据
输    入：*ptr写入数据的指针,n写入数据的长度
返    回：
***************************************************************************************************/
void Write_CS5463(uint8_t *ptr,uint8_t n)
{
  uint8_t  j=0;
  EN_CS();
  for(j=0; j<n; j++)
  {
    stm32_SPI1_SendData(*(ptr+j));
  }
  UN_CS();
}
/***************************************************************************************************
函数名称：void Read_CS5463(uint8_t reg_addr,uint8_t *ptr)
功能描述：读CS5463数据
输    入：reg_addr寄存器地址,*ptr读取数据的指针
返    回：无
***************************************************************************************************/
void Read_CS5463(uint8_t reg_addr,uint8_t *ptr)
{
  uint8_t  i;
  EN_CS();
  stm32_SPI1_SendData(reg_addr);
  for(i=0; i<3; i++)
  {
    *(ptr+i)=stm32_SPI1_SendData(0xff);
  }
  UN_CS();
}

void CS5463_ACgain_Init(void)
{
  uint8_t  temp1[15];
  EE_ACgain_V_ERR=0;                            //X5043电压通道AC增益校准值出错标志清零
  EE_ACgain_I_ERR=0;                            //X5043电流通道AC增益校准值出错标志清零
  RD_X5043_mem(READ_L,0x00,temp1+0,5);          //读X5043的0x00-0x04电压通道AC增益校准值
  RD_X5043_mem(READ_L,0x40,temp1+5,5);          //读X5043的0x40-0x44电压通道AC增益校准值
  RD_X5043_mem(READ_L,0x80,temp1+10,5);         //读X5043的0x80-0x84电压通道AC增益校准值
  if(check_CRC16(&temp1[0],3)==((temp1[3]<<8)|temp1[4]))            //判校准数据的CRC16
  {
    temp1[3]=temp1[2];
    temp1[2]=temp1[1];
    temp1[1]=temp1[0];
  }
  else if(check_CRC16(&temp1[5],3)==((temp1[8]<<8)|temp1[9]))       //判校准数据的CRC16
  {
    temp1[3]=temp1[7];
    temp1[2]=temp1[6];
    temp1[1]=temp1[5];
  }
  else if(check_CRC16(&temp1[10],3)==((temp1[13]<<8)|temp1[14]))    //判校准数据的CRC16
  {
    temp1[3]=temp1[12];
    temp1[2]=temp1[11];
    temp1[1]=temp1[10];
  }
  else
  {
    EE_ACgain_V_ERR=1;                        //X5043电压通道AC增益校准值出错标志置位
  }
  if((EE_ACgain_V_ERR==1)|(EE_ACgain_V_ERR==0))
  {
    temp1[0]=0x48;                            //电压通道增益寄存器
    temp1[1]=0x5e;
    temp1[2]=0xa7;
    temp1[3]=0xe0;
    Write_CS5463(temp1,4);
  }
  RD_X5043_mem(READ_L,0x05,temp1+0,5);          //读X5043的0x05-0x09电流通道AC增益校准值
  RD_X5043_mem(READ_L,0x45,temp1+5,5);          //读X5043的0x45-0x49电流通道AC增益校准值
  RD_X5043_mem(READ_L,0x85,temp1+10,5);         //读X5043的0x85-0x89电流通道AC增益校准值
  if(check_CRC16(&temp1[0],3)==((temp1[3]<<8)|temp1[4]))            //判校准数据的CRC16
  {
    temp1[3]=temp1[2];
    temp1[2]=temp1[1];
    temp1[1]=temp1[0];
  }
  else if(check_CRC16(&temp1[5],3)==((temp1[8]<<8)|temp1[9]))       //判校准数据的CRC16
  {
    temp1[3]=temp1[7];
    temp1[2]=temp1[6];
    temp1[1]=temp1[5];
  }
  else if(check_CRC16(&temp1[10],3)==((temp1[13]<<8)|temp1[14]))    //判校准数据的CRC16
  {
    temp1[3]=temp1[12];
    temp1[2]=temp1[11];
    temp1[1]=temp1[10];
  }
  else
  {
    EE_ACgain_I_ERR=1;                        //X5043电流通道AC增益校准值出错标志置位
  }
  if((EE_ACgain_I_ERR==1)|(EE_ACgain_I_ERR==0))
  {
    temp1[0]=0x44;                            //电流通道增益寄存器
    temp1[1]=0x63;
    temp1[2]=0x5d;
    temp1[3]=0xa5;
    Write_CS5463(temp1,4);
  }
}

/***************************************************************************************************
函数名称：void Clear_Status_Register(void)
功能描述：状态寄存器清零
输    入：无
返    回：无
***************************************************************************************************/
void Clear_Status_Register(void)
{
  uint8_t buf[4];
  buf[0]=0x5e;
  buf[1]=0xff;
  buf[2]=0xff;
  buf[3]=0xff;
  Write_CS5463(buf,4);
}
/***************************************************************************************************
函数名称：uint32_t update_V(void)
功能描述：读电压有效值
输    入：无
返    回：电压有效值(mV)。满度353553mV[((250mV/√2)/100Ω)*200kΩ]
***************************************************************************************************/
uint32_t update_V(void)
{
  uint8_t   tmp[3];
  uint32_t  V_V;
  Read_CS5463(VOLT_RMS,tmp);                              //二进制电压
  V_V=(tmp[0]<<24)|(tmp[1]<<16)|(tmp[2]<<8);              //V_V*256
  V_V=V_V/12148;                                          //(0xFFFFFF*256)/353553=12148.014
  //  if(V_V<10000) V_V=0;
  return V_V;
}
/***************************************************************************************************
函数名称：uint32_t update_I(void)
功能描述：读电流有效值
输    入：无
返    回：电流有效值(mA)。满度2156mA[((250mV/√2)/82Ω)*(5A/5mA)]
***************************************************************************************************/
uint32_t update_I(void)
{
  uint8_t   tmp[3];
  uint32_t  I_I;
  Read_CS5463(CURRENT_RMS,tmp);                           //二进制电流
  I_I=(tmp[0]<<24)|(tmp[1]<<16)|(tmp[2]<<8);              //I_I*256
  I_I=(I_I/1992100);                                      //(0xFFFFFF*256)/2156=1992099.740
  //  if(I_I<6) I_I=0;
  return I_I;
}
/***************************************************************************************************
函数名称：uint32_t update_P(void)
功能描述：读有功功率
输    入：无
返    回：有功功率(mW)。满度762260mW[353553mV*2156mA]
***************************************************************************************************/
uint32_t update_P(void)
{
  uint8_t   tmp[3];
  uint32_t  P_P;
  Read_CS5463(Pactive,tmp);                               //二进制功率
  if((tmp[0]&0x80)==0)
  {
    P_P=(tmp[0]<<25)|(tmp[1]<<17)|(tmp[2]<<9);          //(+)P_P*256*2
  }
  else
  {
    P_P=(~((tmp[0]<<25)|(tmp[1]<<17)|(tmp[2]<<9)))+1;   //(-)P_P*256*2
  }
  P_P=(P_P/5634);                                       //(0x7FFFFF*256*2)/762260=5634.516
  //  if(P_P<1000) P_P=0;
  return P_P;
}
/***************************************************************************************************
函数名称：uint32_t update_pf(void)
功能描述：读功率因数
输    入：无
返    回：功率因数(百分比*10000)
***************************************************************************************************/
uint32_t update_pf(void)
{
  uint8_t   tmp[3];
  uint32_t  pf_pf;
  Read_CS5463(PowerFactor,tmp);                           //二进制功率因数
  if((tmp[0]&0x80)==0)
  {
    pf_pf=(tmp[0]<<25)|(tmp[1]<<17)|(tmp[2]<<9);        //(+)pf_pf*256*2
  }
  else
  {
    pf_pf=(~((tmp[0]<<25)|(tmp[1]<<17)|(tmp[2]<<9)))+1; //(-)pf_pf*256*2
  }
  pf_pf=pf_pf/429496;                                     //(0x7FFFFF*256*2)/10000=429496.6784
  return pf_pf;
}
/***************************************************************************************************
函数名称：uint16_t update_T(void)
功能描述：读温度值
输    入：无
返    回：温度值(℃*100)
***************************************************************************************************/
uint32_t update_T(void)
{
  uint8_t   tmp[3];
  uint32_t  Celsius=0;
  Read_CS5463(Temperature,tmp);                           //二进制温度
  if((tmp[0]&0x80)==0)
  {
    Celsius=(tmp[0]<<16)|(tmp[1]<<8)|(tmp[2]);          //(+)
  }
  else
  {
    Celsius=(~((tmp[0]<<16)|(tmp[1]<<8)|(tmp[2])))+1;   //(-)
  }
  Celsius=(Celsius*100)/0x10000;
  return Celsius;
}

/***************************************************************************************************
函数名称：uint16_t check_CRC16(uint8_t *dat,uint8_t cnt)
功能描述：计算cnt个字节的CRC16
输    入：dat计算crc数据指针，cnt长度
返    回：温度值(℃*100)
***************************************************************************************************/
uint16_t check_CRC16(uint8_t *dat,uint8_t cnt)  //
{
  uint8_t   i;
  uint16_t  crc16=0;
  for(i=0; i<cnt; i++)
  {
    crc16+=(uint16_t)dat[i];
  }
  return crc16;
}

/***************************************************************************************************
函数名称：float foar(float ff,uint8_t *pp,uint8_t k)
功能描述：
输    入：
返    回：
***************************************************************************************************/
float foar(float ff,uint8_t *pp,uint8_t k)
{
  union UFLOAT
  {
    float	f;
    uint8_t	by4[4];
  } uf;
  uint8_t  i;
  if(k==1)
  {
    uf.f=ff;
    for(i=0; i<4; i++,pp++)
      *pp=uf.by4[i];
  }
  else
  {
    for(i=0; i<4; i++)
      uf.by4[i]=*pp++;
  }
  return uf.f;
}

/***************************************************************************************************
函数名称：void AppParamsUpdata(void)
功能描述: 误差1%以上参数更新平台工作状态
输    入：无
返    回：无
***************************************************************************************************/
void AppParamsUpdata(void)
{
  static uint8_t vtest = 1;
  static fPOWER  fpowerb;
  if(vtest)
  {
    fpowerb.fV = fpower.fV;
    fpowerb.fI = fpower.fI;
    fpowerb.fP = fpower.fP;
    vtest = 0;
  }
  else
  {
    float value = fabs(fpowerb.fV - fpower.fV);
    float value1 = 100*value;
    if(value1> fpower.fV)
      BKPSRAM->AppParamsUp = 0x11;

    value = fabs(fpowerb.fI - fpower.fI);
    value1 = 50*value;
    if(value1> fpower.fI)
      BKPSRAM->AppParamsUp = 0x11;
    vtest = 1;
  }
}
/***************************************************************************************************
函数名称：void AlarmCheck(void)
功能描述:报警参数检测
输    入：无
返    回：无
***************************************************************************************************/
void AlarmCheck(void)
{
  static uint8_t voltcnt = 0,vi1 = 0,vi2 = 0;
  if(fpower.fV > 270) 																//检测是否过压
  {
    voltcnt++;
    if(voltcnt >= 5)
    {
      voltcnt = 0;
      BKPSRAM->AlarmCode = ALARM_OVERVOLTAGE;
    }
  }
  else
  {
    voltcnt = 0;
  }

  if(JDQ_Status==1)
  {
    if(fpower.fV > 200 && fpower.fI > 4 )				//检测电源是否短路坏
    {
      vi1++;
      if(vi1 >= 5)
      {
        vi1 = 0;
        BKPSRAM->AlarmCode = ALARM_POWERFAULT;
      }
    }
    else
    {
      vi1 = 0;
    }

    if(fpower.fV > 200 && (fpower.fP >= 0 && fpower.fP < 5))				//检测电源是否开路坏
    {
      vi2++;
      if(vi2 >= 5)
      {
        vi2 = 0;
        BKPSRAM->AlarmCode = ALARM_POWERFAULT;
      }
    }
    else
    {
      vi2 = 0;
    }
}
}
/***************************************************************************************************
函数名称：void CS5463_Handel(void)
功能描述：执行计量检测
输    入：无
返    回：无
***************************************************************************************************/
void CS5463_Handel(void)
{
  static uint8_t flag = 0;
  uint16_t  T_check;
  uint8_t   temp3[12]= {0};
  flag ++;
  if(flag >= 6)
  {
    CS5463_Init();
    flag = 0;
    HAL_Delay(200);
  }
  Read_CS5463(0x1e,temp3);                        //读状态寄存器(1E)
  if((temp3[0]&0x80)==0x80)                       //数据就绪(一个计算周期结束)
  {
    float  temp = 0;
    flag = 0;
    IWDG_Feed();
    Clear_Status_Register();                    	//CS5463状态寄存器清零
    power_update();                             	//更新电测值
    fpower.fV=((float)power.V)/1000;
    fpower.fI=((float)power.I)/1000;
    temp=(float)power.P;
    fpower.fP=temp/1000;
    fpower.fpf=((float)power.pf)/10000;
    fpower.feps=temp/3600;
    AlarmCheck();
    IWDG_Feed();
    AppParamsUpdata();
		//校准后电流电压
		BKPSRAM->Curr_Calib = BKPSRAM->Curr_Scale*(fpower.fI - BKPSRAM->Curr_Zero_Shift);
		BKPSRAM ->Volt_Calib =  BKPSRAM->Volt_Scale*(fpower.fV - BKPSRAM->Volt_Zero_Shift);
		BKPSRAM->ActivePower =  BKPSRAM->Curr_Calib * BKPSRAM ->Volt_Calib;
		BKPSRAM->PowerRadio = fpower.fpf;
    if(JDQ_Status==1)                           //开灯状态下,计算累计电能量、累计时间
    {
      mark_total_powerP=1;                      //计算累计电能量
      total_powerP=total_powerP+fpower.feps;
      mark_total_powerP=0;
      mark_total_powerP_bk1=1;
      total_powerP_bk1=total_powerP;
      mark_total_powerP_bk1=0;
      mark_total_powerP_bk2=1;
      total_powerP_bk2=total_powerP;
      mark_total_powerP_bk2=0;
      mark_total_time=1;                     		 //计算累计时间
      total_time+=2;
      mark_total_time=0;
      mark_total_time_bk1=1;
      total_time_bk1=total_time;
      mark_total_time_bk1=0;
      mark_total_time_bk2=1;
      total_time_bk2=total_time;
      mark_total_time_bk2=0;
      mark_array_bk0=1;                          //数据array备份
      if(mark_total_powerP==0)
      {
        foar(total_powerP,array_bk0,1);        //累计电能量转数组
        T_check=check_CRC16(&array_bk0[0],4);
        array_bk0[4]=(uint8_t)(T_check>>8);
        array_bk0[5]=(uint8_t)T_check;
      }
      else if(mark_total_powerP_bk1==0)
      {
        foar(total_powerP_bk1,array_bk0,1);
        T_check=check_CRC16(&array_bk0[0],4);
        array_bk0[4]=(uint8_t)(T_check>>8);
        array_bk0[5]=(uint8_t)T_check;
      }
      else if(mark_total_powerP_bk2==0)
      {
        foar(total_powerP_bk2,array_bk0,1);
        T_check=check_CRC16(&array_bk0[0],4);
        array_bk0[4]=(uint8_t)(T_check>>8);
        array_bk0[5]=(uint8_t)T_check;
      }
      if(mark_total_time==0)
      {
        array_bk0[6]=(uint8_t)(total_time);    //累计时间转数组
        array_bk0[7]=(uint8_t)(total_time>>8);
        array_bk0[8]=(uint8_t)(total_time>>16);
        array_bk0[9]=(uint8_t)(total_time>>24);
        T_check=check_CRC16(&array_bk0[6],4);
        array_bk0[10]=(uint8_t)(T_check>>8);
        array_bk0[11]=(uint8_t)T_check;
      }
      else if(mark_total_time_bk1==0)
      {
        array_bk0[6]=(uint8_t)(total_time_bk1);
        array_bk0[7]=(uint8_t)(total_time_bk1>>8);
        array_bk0[8]=(uint8_t)(total_time_bk1>>16);
        array_bk0[9]=(uint8_t)(total_time_bk1>>24);
        T_check=check_CRC16(&array_bk0[6],4);
        array_bk0[10]=(uint8_t)(T_check>>8);
        array_bk0[11]=(uint8_t)T_check;
      }
      else if(mark_total_time_bk2==0)
      {
        array_bk0[6]=(uint8_t)(total_time_bk2);
        array_bk0[7]=(uint8_t)(total_time_bk2>>8);
        array_bk0[8]=(uint8_t)(total_time_bk2>>16);
        array_bk0[9]=(uint8_t)(total_time_bk2>>24);
        T_check=check_CRC16(&array_bk0[6],4);
        array_bk0[10]=(uint8_t)(T_check>>8);
        array_bk0[11]=(uint8_t)T_check;
      }
      mark_array_bk0=0;
      mark_array_bk1=1;
      array_bk1[0]=array_bk0[0];
      array_bk1[1]=array_bk0[1];
      array_bk1[2]=array_bk0[2];
      array_bk1[3]=array_bk0[3];
      array_bk1[4]=array_bk0[4];
      array_bk1[5]=array_bk0[5];
      array_bk1[6]=array_bk0[6];
      array_bk1[7]=array_bk0[7];
      array_bk1[8]=array_bk0[8];
      array_bk1[9]=array_bk0[9];
      array_bk1[10]=array_bk0[10];
      array_bk1[11]=array_bk0[11];
      mark_array_bk1=0;
      mark_array_bk2=1;
      array_bk2[0]=array_bk0[0];
      array_bk2[1]=array_bk0[1];
      array_bk2[2]=array_bk0[2];
      array_bk2[3]=array_bk0[3];
      array_bk2[4]=array_bk0[4];
      array_bk2[5]=array_bk0[5];
      array_bk2[6]=array_bk0[6];
      array_bk2[7]=array_bk0[7];
      array_bk2[8]=array_bk0[8];
      array_bk2[9]=array_bk0[9];
      array_bk2[10]=array_bk0[10];
      array_bk2[11]=array_bk0[11];
      mark_array_bk2=0;
    }
  }
}

/***************************************************************************************************
函数名称：void total_Init(void)
功能描述：累计值初始化
输    入：无
返    回：无
***************************************************************************************************/
void total_Init(void)
{
  uint16_t  temp0;
  float     temp1;
  uint16_t  T_check;
  RD_X5043_mem(READ_H,0x00,&array_bk0[0],12);
  T_check=check_CRC16(&array_bk0[0],4);                   //计算累计电能量数据的CRC16
  temp0=(uint16_t)(array_bk0[4]<<8);                      //CRC16高8位
  temp0=temp0|array_bk0[5];                               //CRC16低8位
  if(T_check==temp0)
  {
    T_check=check_CRC16(&array_bk0[6],4);               //计算累计时间数据的CRC16
    temp0=(uint16_t)(array_bk0[10]<<8);                 //CRC16高8位
    temp0=temp0|array_bk0[11];                          //CRC16低8位
    if(T_check==temp0)
    {
      total_powerP=foar(temp1,&array_bk0[0],0);       //k=0,数组转浮点数
      total_powerP_bk1=total_powerP;
      total_powerP_bk2=total_powerP;
      total_time=((array_bk0[9]<<24)|(array_bk0[8]<<16)|(array_bk0[7]<<8)|(array_bk0[6]));
      total_time_bk1=total_time;
      total_time_bk2=total_time;
      mark_total_Init_ERR=0;
    }
    else mark_total_Init_ERR=1;
  }
  else mark_total_Init_ERR=1;
  if(mark_total_Init_ERR==1)
  {
    RD_X5043_mem(READ_H,0x40,&array_bk0[0],12);
    T_check=check_CRC16(&array_bk0[0],4);               //计算累计电能量数据的CRC16
    temp0=(uint16_t)(array_bk0[4]<<8);                  //CRC16高8位
    temp0=temp0|array_bk0[5];                           //CRC16低8位
    if(T_check==temp0)
    {
      T_check=check_CRC16(&array_bk0[6],4);           //计算累计时间数据的CRC16
      temp0=(uint16_t)(array_bk0[10]<<8);             //CRC16高8位
      temp0=temp0|array_bk0[11];                      //CRC16低8位
      if(T_check==temp0)
      {
        total_powerP=foar(temp1,&array_bk0[0],0);   //k=0,数组转浮点数
        total_powerP_bk1=total_powerP;
        total_powerP_bk2=total_powerP;
        total_time=((array_bk0[9]<<24)|(array_bk0[8]<<16)|(array_bk0[7]<<8)|(array_bk0[6]));
        total_time_bk1=total_time;
        total_time_bk2=total_time;
        mark_total_Init_ERR=0;
      }
      else mark_total_Init_ERR=1;
    }
    else mark_total_Init_ERR=1;
  }
  if(mark_total_Init_ERR==1)
  {
    RD_X5043_mem(READ_H,0x80,&array_bk0[0],12);
    T_check=check_CRC16(&array_bk0[0],4);               //计算累计电能量数据的CRC16
    temp0=(uint16_t)(array_bk0[4]<<8);                  //CRC16高8位
    temp0=temp0|array_bk0[5];                           //CRC16低8位
    if(T_check==temp0)
    {
      T_check=check_CRC16(&array_bk0[6],4);           //计算累计时间数据的CRC16
      temp0=(uint16_t)(array_bk0[10]<<8);             //CRC16高8位
      temp0=temp0|array_bk0[11];                      //CRC16低8位
      if(T_check==temp0)
      {
        total_powerP=foar(temp1,&array_bk0[0],0);   //k=0,数组转浮点数
        total_powerP_bk1=total_powerP;
        total_powerP_bk2=total_powerP;
        total_time=((array_bk0[9]<<24)|(array_bk0[8]<<16)|(array_bk0[7]<<8)|(array_bk0[6]));
        total_time_bk1=total_time;
        total_time_bk2=total_time;
        mark_total_Init_ERR=0;
      }
      else
      {
        total_powerP=0;
        total_powerP_bk1=0;
        total_powerP_bk2=0;
        total_time=0;
        total_time_bk1=0;
        total_time_bk2=0;
        mark_total_Init_ERR=1;
      }
    }
    else
    {
      total_powerP=0;
      total_powerP_bk1=0;
      total_powerP_bk2=0;
      total_time=0;
      total_time_bk1=0;
      total_time_bk2=0;
      mark_total_Init_ERR=1;
    }
  }
}

/***************************************************************************************************
函数名称：void EnergyMeasureTask(void const * argument)
功能描述：x5043检测任务
输    入：无
返    回：无
***************************************************************************************************/
void EnergyMeasureTask(void const * argument)
{
  static uint8_t count = 0;
  for(;;)
  {
    IWDG_Feed();
    if(++count >= 2)
    {
      count = 0;
      CS5463_Handel();
    }
    IWDG_Feed();
    ReadTime();
    osDelay(1000);
  }
}
