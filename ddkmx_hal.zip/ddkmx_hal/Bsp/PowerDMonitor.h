#ifndef   __PowerDMonitor_H
#define   __PowerDMonitor_H

extern	uint8_t  array_bk0[16];                        //写入X5043的数据存储区0
extern	uint8_t  array_bk1[16];                        //写入X5043的数据存储区1
extern	uint8_t  array_bk2[16];                        //写入X5043的数据存储区2

#endif
