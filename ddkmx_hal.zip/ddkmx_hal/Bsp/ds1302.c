#include "main.h"
#include "ds1302.h"
#include "dim.h"
#include "time.h"
#include "set.h"
#include "flash.h"
#include "x5043.h"

#define   SECONDS    0x80                                 //DS1302的日历时钟写地址,读地址(+1)
#define   MINUTES    0x82
#define   HOUR       0x84
#define   DATE       0x86
#define   MONTH      0x88
#define   DAY        0x8a
#define   YEAR       0x8c
#define   RAM_Base   0xc0                                 //DS1302的起始RAM写地址
#define   DS_Port    GPIOB                                //DS1302的GPIO口
#define   DS_CE      GPIO_PIN_5                           //CE的GPIO口线
#define   DS_IO      GPIO_PIN_7                           //IO的GPIO口线
#define   DS_CLK     GPIO_PIN_6                           //CLK的GPIO口线
#define   SetCE      HAL_GPIO_WritePin(DS_Port,DS_CE,GPIO_PIN_SET);          //CE=1
#define   ClrCE      HAL_GPIO_WritePin(DS_Port,DS_CE,GPIO_PIN_RESET);        //CE=0
#define   SetIO      HAL_GPIO_WritePin(DS_Port,DS_IO,GPIO_PIN_SET);          //IO=1
#define   ClrIO      HAL_GPIO_WritePin(DS_Port,DS_IO,GPIO_PIN_RESET);        //IO=0
#define   SetCLK     HAL_GPIO_WritePin(DS_Port,DS_CLK,GPIO_PIN_SET);         //CLK=1
#define   ClrCLK     HAL_GPIO_WritePin(DS_Port,DS_CLK,GPIO_PIN_RESET);       //CLK=0
#define   ReadIO     HAL_GPIO_ReadPin(DS_Port,DS_IO)  											 //读IO口线

static void DelayNOP(uint32_t count);                          //延时
void set_io_input(void);                                  //DS1302的I/O引脚--输入
void set_io_output(void);                                 //DS1302的I/O引脚--输出
unsigned char spi_rbyte(void);                            //移位读取DS1302(8bit)
void spi_wbyte(unsigned char byte);                       //移位写入DS1302(8bit)
unsigned char ds_rbyte(unsigned char add);                //DS1302读1字节
void ds_wbyte(unsigned char add,unsigned char byte);      //DS1302写1字节
void clk_rburst(unsigned char *clk);                      //时钟突发模式--读
void clk_wburst(unsigned char *clk);                      //时钟突发模式--写
unsigned char ds_read_ram(unsigned char ram_offset);            //RAM读1字节
void ds_write_ram(unsigned char ram_offset,unsigned char dat);  //RAM写1字节
void ds_WriteEnable(void);                                //DS1302写使能
void ds_WriteDisable(void);                               //DS1302写禁止
void SetTime(void);
unsigned char  Time_W[8]= {0x00,0x00,0x12,0x01,0x08,0x04,0x19,0x00}; //{0x00,0x00,0x15,0x11,0x08,0x05,0x17,0x00}
//设置时钟数组[秒,分,时,日,月,星期,年,使能]
unsigned char  Time_R[8];                                 //读取时钟数组[秒,分,时,日,月,星期,年,使能]
unsigned char  Ram_W[31];                                 //写入Ram数据的数组
unsigned char  Ram_R[31];                                 //读出Ram数据的数组

void DS1302_Init(void)  //DS1302初始化
{
  ClrCE;                                                  //CE=0
  ClrIO;                                                  //I/O=0
  ClrCLK;                                                 //SCLK=0
  //DS1302日历时钟是否送初始值
  if((ds_rbyte(0x91))!=0xaa)                              //读涓流充电寄存器址91h
  {
    ds_WriteEnable();                                   //DS1302写使能(+Delay)
    ds_wbyte(0x90,0xaa);                                //写涓流充电寄存器90h,1 Diode/2kΩ(+Delay)
    ds_WriteDisable();                                  //DS1302写禁止
		SetTime();                                          //非0xa5(上电0x5c),日历时钟送初始值(+Delay)
		CurrCalibDownload(0,1);															//电流零点漂移和比例系数初始值
		HAL_Delay(200);
    VoltCalibDownload(0,1);															//电压零点漂移和比例系数初始值
		_Iot_Init();
	}
}

/***************************************************************************************************
函数名称：void ReadTime(void) 
功能描述：读取DS1302时钟
输    入：无
返    回：无
***************************************************************************************************/
void ReadTime(void)  
{
  clk_rburst(Time_R);                                     //时钟单元读入Time_R[8]
  if(BKPSRAM->stLightTimerFlag == 0x12)
  {
    time_t time = 0;
    struct tm stm_1302;
    stm_1302.tm_wday = RTC_Bcd2ToByte(Time_R[5]);
    stm_1302.tm_hour = RTC_Bcd2ToByte(Time_R[2]);
    stm_1302.tm_min  = RTC_Bcd2ToByte(Time_R[1]);
    time = stm_1302.tm_hour*60+stm_1302.tm_min;
    if(BKPSRAM->stLightTimerNum > 0)
    {
      for(int i=0; i<BKPSRAM->stLightTimerNum; i++)
      {
        if(BKPSRAM->stLightTimerList[i].days == stm_1302.tm_wday)
        {
          if(BKPSRAM->stLightTimerList[i].time == time )
          {
            if(BKPSRAM->stLightTimerList[i].action == 0)
            {
              if(JDQ_Status == 1)
              {
                JDQ_OFF();//断电 status=0;
								BKPSRAM->LightLevel = 0 ;
								BKPSRAM->AppParamsUp = 0x11;
              }
            }
            else
            {
              if(JDQ_Status == 0)
              {
                JDQ_ON();//通电 status=1
								if(BKPSRAM->stLightTimerList[i].action < BKPSRAM->colortemp_lowlimit)
									BKPSRAM->LightLevel = BKPSRAM->colortemp_lowlimit;
								else 
									BKPSRAM->LightLevel = BKPSRAM->stLightTimerList[i].action ;
                SetPWR_Duty(BKPSRAM->LightLevel);
								BKPSRAM->AppParamsUp = 0x11;
              }
            }

          }
        }
      }
    }
  }
}

/***************************************************************************************************
函数名称：void SetTime(void) 
功能描述：设置DS1302时钟
输    入：无
返    回：无
***************************************************************************************************/
void SetTime(void)  
{
  clk_wburst(Time_W);                                    	//Time_W[8]写入时钟单元(+Delay)
}

static void DelayNOP(uint32_t count)  						//延时:25-6μs,10-3μs,5-2.08μs
{
  while(count--) __NOP();
}

/***************************************************************************************************
函数名称：void set_io_input(void) 
功能描述：DS1302的I/O引脚--输入
输    入：无
返    回：无
***************************************************************************************************/
void set_io_input(void)  
{
  GPIO_InitTypeDef  GPIO_InitStruct;                   		//GPIO初始化结构体
  GPIO_InitStruct.Pin = DS_IO;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  HAL_GPIO_Init(DS_Port,&GPIO_InitStruct);                 	//DS1302的I/O引脚--输入
}

/***************************************************************************************************
函数名称：void set_io_output(void) 
功能描述：DS1302的I/O引脚--输出
输    入：无
返    回：无
***************************************************************************************************/
void set_io_output(void)  //DS1302的I/O引脚--输出
{
  GPIO_InitTypeDef  GPIO_InitStruct;                   		//GPIO初始化结构体
  GPIO_InitStruct.Pin=DS_IO;                      			//DS1302的I/O引脚
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(DS_Port,&GPIO_InitStruct);                 	//DS1302的I/O引脚--输出
}

/***************************************************************************************************
函数名称：unsigned char spi_rbyte(void)
功能描述：移位读取DS1302(8bit)
输    入：无
返    回：读取的数据
***************************************************************************************************/
unsigned char spi_rbyte(void)  //
{
  unsigned char  byte=0x00,i;
  DelayNOP(5);
  for(i=0; i<8; i++)
  {
    byte>>=1;                                           	//低位在前
    if(ReadIO!=0)  byte|=0x80;
    SetCLK;                                             	//SCLK=1:MIN1μs
    DelayNOP(5);
    ClrCLK;                                             	//SCLK=0:MIN1μs
    DelayNOP(5);                                        	//SCLK-IO:MAX800ns
  }
  return byte;
}

/***************************************************************************************************
函数名称：void spi_wbyte(unsigned char byte)
功能描述：移位写入DS1302(8bit)
输    入：写入的数据
返    回：无
***************************************************************************************************/
void spi_wbyte(unsigned char byte)  
{
  unsigned char  i;
  for(i=0; i<8; i++)
  {
    if((byte&0x01)==0)                                  //低位在前
    {
      ClrIO;
    }
    else
    {
      SetIO;
    }
    DelayNOP(5);                                        //IO-SCLK:MIN200ns
    SetCLK;                                             //SCLK=1:MIN1μs
    DelayNOP(5);                                        //SCLK-IO:MIN280ns
    ClrCLK;                                             //SCLK=0:MIN1μs
    byte>>=1;
  }
}

/***************************************************************************************************
函数名称：unsigned char ds_rbyte(unsigned char add)
功能描述：DS1302读1字节
输    入：读字节地址
返    回：读出的数据
***************************************************************************************************/
unsigned char ds_rbyte(unsigned char add)  //
{
  unsigned char  byte;
  SetCE;                                                  //CE-SCLK:MIN4μs(+Delay)
  spi_wbyte(add|0x01);                                    //命令
  set_io_input();
  byte=spi_rbyte();                                       //读1字节
  ClrCE;                                                  //CE=0:MIN4μs
  DelayNOP(5);
  set_io_output();
  return byte;
}

/***************************************************************************************************
函数名称：void ds_wbyte(unsigned char add,unsigned char byte)
功能描述：DS1302写1字节
输    入：写入的字节地址和数据
返    回：无
***************************************************************************************************/
void ds_wbyte(unsigned char add,unsigned char byte)  
{
  SetCE;                                                  //CE-SCLK:MIN4μs(+Delay)
  spi_wbyte(add);                                         //命令
  spi_wbyte(byte);                                        //写1字节
  ClrCE;                                                  //CE=0:MIN4μs
  DelayNOP(5);
}

/***************************************************************************************************
函数名称：void clk_rburst(unsigned char *clk) 
功能描述：时钟突发模式--读
输    入：
返    回：无
***************************************************************************************************/
void clk_rburst(unsigned char *clk)  					
{
  unsigned char  i;
  SetCE;                                                  //(+Delay)
  spi_wbyte(0xbf);                                        //命令
  set_io_input();
  for(i=0; i<8; i++)                                      //读8字节
  {
    *clk=spi_rbyte();
    clk++;
  }
  ClrCE;
  set_io_output();
}

/***************************************************************************************************
函数名称：void ram_rburst(unsigned char *ram,unsigned char cnt) 
功能描述：RAM突发模式--读
输    入：
返    回：无
***************************************************************************************************/
void ram_rburst(unsigned char *ram,unsigned char cnt)  //
{
  unsigned char  i;
  SetCE;                                                  //(+Delay)
  spi_wbyte(0xff);                                        //命令
  set_io_input();
  for(i=0; i<cnt; i++)                                    //读cnt字节
  {
    *ram=spi_rbyte();
    ram++;
  }
  ClrCE;
  set_io_output();
}

/***************************************************************************************************
函数名称：void clk_rburst(unsigned char *clk) 
功能描述：时钟突发模式--写
输    入：
返    回：无
***************************************************************************************************/
void clk_wburst(unsigned char *clk)  
{
  unsigned char  i;
  ds_WriteEnable();                                       //DS1302写使能(+Delay)
  SetCE;                                                  //(+Delay)
  spi_wbyte(0xbe);                                        //命令
  for(i=0; i<8; i++)                                      //写8字节
  {
    spi_wbyte(*clk);
    clk++;
  }
  ClrCE;
  ds_WriteDisable();                                      //DS1302写禁止
}

/***************************************************************************************************
函数名称：void ds_WriteEnable(void) 
功能描述：DS1302写使能
输    入：无
返    回：无
***************************************************************************************************/
void ds_WriteEnable(void)  //
{
  ds_wbyte(0x8e,0x00);                                    //WP=0
}

/***************************************************************************************************
函数名称：void ds_WriteDisable(void)
功能描述：DS1302写禁止
输    入：无
返    回：无
***************************************************************************************************/
void ds_WriteDisable(void)  
{
  ds_wbyte(0x8e,0x80);                                    //WP=1
}


